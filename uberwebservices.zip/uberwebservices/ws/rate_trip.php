<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if (!isset($_POST[MOB_REQUEST_RANDOM_ID]) || empty($_POST[MOB_REQUEST_RANDOM_ID])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $trip_id = $_POST[MOB_REQUEST_RANDOM_ID];

    if (!isset($_POST[MOB_FEEDBACK_COMMENT]) || empty($_POST[MOB_FEEDBACK_COMMENT])) {
        $cli_comment = "";
    } else {
        $cli_comment = $_POST[MOB_FEEDBACK_COMMENT];
    }
    if (!isset($_POST[MOB_FEEDBACK_RATE]) || empty($_POST[MOB_FEEDBACK_RATE])) {
        $cli_rate = "0";
    } else {
        $cli_rate = $_POST[MOB_FEEDBACK_RATE];
    }

    $get_trip_data = mysql_query("SELECT * FROM " . REQUEST_DATA . " WHERE random_id='$trip_id'");
    $check_trip = mysql_num_rows($get_trip_data);
    if ($check_trip > 0) {
        $client_id = "";
        while ($row = mysql_fetch_assoc($get_trip_data)) {
            $request_id = $row['request_id'];
            $raandom_id = $row['random_id'];
            $request_time = $row['request_time'];
            $lat = $row['lattitude'];
            $long = $row['logitude'];
            $client_id = $row['client_id'];
            $driver_id = $row['driver_id'];
            $pick_time = $row['time_of_pickup'];
            $req_stat = $row['request_status']; /* 0 no driver assign , 1 driver assign */
            $comp_stat = $row['complete_status']; /* 0 not completed , 1 completed */
            $cancel_flg = $row['cancel_flg']; /* 0 not cancled , 1 cancled */
        }
        $dateNow = date('Y-m-d H:i:s', time());

        $add_feedback = mysql_query("INSERT INTO " . FEEDBACK_DATA . "( request_id, driver_id, client_id, time, rating, comment) VALUES ('$request_id','$driver_id','$client_id','$dateNow','$cli_rate','$cli_comment')");

        $get_all_rates = mysql_query("SELECT * FROM " . FEEDBACK_DATA . " WHERE driver_id='$driver_id'");
        $count_all_rates = mysql_num_rows($get_all_rates);
        if ($count_all_rates > 0) {
            $avg_rates = 0.0;
            $rates_count = 0;
            while ($count_all_rates > 0) {
                while ($row1 = mysql_fetch_array($get_all_rates)) {
                    $avg_rates += (float) $row1['rating'];
                }
                $rates_count++;
                $count_all_rates--;
            }
            $avg_rates = number_format(($avg_rates / $rates_count), 2, '.', '');
            $update_driver = mysql_query("UPDATE " . DRIVER_DATA . " SET rating='$avg_rates',rating_count='$rates_count',random_id=(NULL) WHERE driver_id='$driver_id'");
            $update_client = mysql_query("UPDATE " . REQUEST_DATA . " SET complete_status=0,drop_time=0,driver_reached_time=0 WHERE client_id='$client_id'");
//            $delete_client_request = mysql_query("DELETE FROM ".REQUEST_DATA." WHERE random_id='{$raandom_id}'");
            $response = array(STATUS => SUCCESS, MESSAGE => RATE_DONE);
        } else {
            $response = array(STATUS => FAIL, MESSAGE => RATE_NOT_FOUND);
        }
    } else {
        $response = array(STATUS => FAIL, MESSAGE => TRIP_NOT_FOUND);
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>