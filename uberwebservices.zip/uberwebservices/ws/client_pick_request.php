<?php

include_once './const.php';
include_once './config.php';
include_once './random4.php';
include_once './apns.php';

date_default_timezone_set("" . DATE_FORMATE . "");
$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
if ((!isset($_POST[MOB_REQUEST_LAT]) || empty($_POST[MOB_REQUEST_LAT])) || (!isset($_POST[MOB_REQUEST_LONG]) || empty($_POST[MOB_REQUEST_LONG])) || (!isset($_POST[MOB_REQUEST_CLIENT_ID]) || empty($_POST[MOB_REQUEST_CLIENT_ID])) || (!isset($_POST['car_washing']) || empty($_POST['car_washing'])) || (!isset($_POST['fuel_topup']) || empty($_POST['fuel_topup'])) || (!isset($_POST['payment_status']) || empty($_POST['payment_status'])|| (!isset($_POST['pay_id']) || empty($_POST['pay_id'])))) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $lat = $_POST[MOB_REQUEST_LAT];
    $long = $_POST[MOB_REQUEST_LONG];
    $client_id = $_POST[MOB_REQUEST_CLIENT_ID];
    $car_washing = $_POST['car_washing'];
    $fuel_topup = $_POST['fuel_topup'];
    $payment_status = $_POST['payment_status'];
    $pay_id = $_POST['pay_id'];
    $dateNow = date('Y-m-d H:i:sP', time());
    $code = my_random4_number();
    $add_request = mysql_query("Insert into " . REQUEST_DATA . " (`client_id`,`random_id`,`lattitude`,`logitude`,`car_washing`,`fuel_topup`,`payment_status`,`pay_id`)VALUES({$client_id},'{$code}',{$lat},{$long},'{$car_washing}','{$fuel_topup}','{$payment_status}','{$pay_id}')");
    if ($add_request) {
        $random = mysql_query("SELECT * from client_request_data WHERE client_id={$client_id}");
        $random = mysql_fetch_assoc($random);
        $rand = $random['random_id'];
        $time = $random['time_of_pickup'];
        $details = array();
        if ($random) {
            $driver_select = mysql_query("SELECT *,
            111.045* DEGREES(ACOS(COS(RADIANS(latpoint))
            * COS(RADIANS(lattitude))
            * COS(RADIANS(longpoint) - RADIANS(logitude))
            + SIN(RADIANS(latpoint))
            * SIN(RADIANS(lattitude)))) AS distance_in_km
            FROM driver_data
            JOIN (
            SELECT $lat AS latpoint, $long AS longpoint
            ) AS p ON 1 = 1
            ORDER BY distance_in_km
            LIMIT 1");
            $driver_nearby = "";
            while ($row = mysql_fetch_assoc($driver_select)) {
                $driver_nearby = $row['driver_id'];
            };
            $driver_insert = mysql_query("Update driver_data SET random_id = '" . $code . $insert_id . "' WHERE driver_id = {$driver_nearby}");
            $driver_token = mysql_query("SELECT `device_token` from driver_data WHERE driver_id = {$driver_nearby}");
            $driver_token = mysql_fetch_assoc($driver_token);
            $driver_token = $driver_token['device_token'];
            $driver_token = str_replace(' ', '', $driver_token);
            $message = array(
                'id' => '1',
                'random_id' => $rand,
                'time_of_pickup' => $time,
                'status' => 'succesfull',
                'message' => 'hello'
            );
            $Objapns = new Apns_Client();
            $Objapns->send_notification($driver_token, $message);
            $driver_request = mysql_query("SELECT client_request_data.request_id, client_request_data.random_id, client_request_data.request_time, client_request_data.lattitude, client_request_data.logitude, client_request_data.client_id, client_request_data.time_of_pickup, client_request_data.driver_reached_time, client_request_data.request_status, client_request_data.complete_status, client_request_data.cancel_flg,client_request_data.end_lat,client_request_data.end_long,client_data.name,client_data.email,client_request_data.car_washing,client_request_data.fuel_topup,client_request_data.payment_status,driver_data.profile_image
                                FROM client_request_data
                                LEFT JOIN client_data
                                ON client_request_data.client_id = client_data.client_id
                                LEFT JOIN driver_data
                                ON client_request_data.random_id = driver_data.random_id
                                WHERE client_request_data.random_id = '" . $code . $insert_id . "'");
            $driver_response = mysql_fetch_assoc($driver_request);
            $driver_profile_image = $driver_response['profile_image'];
            $client = mysql_query("SELECT time_of_pickup from client_request_data WHERE client_id = {$client_id} AND lattitude = {$lat} AND logitude = {$long} AND random_id = '" . $code . $insert_id . "'");
            $client_response = mysql_fetch_assoc($client);
            $time_of_pickup = $client_response['time_of_pickup'];
            $details = array(MOB_REQUEST_ID => "" . $insert_id, MOB_REQUEST_RANDOM_ID => $code . $insert_id, MOB_REQUEST_TIME => $dateNow, MOB_REQUEST_LAT => $lat, MOB_REQUEST_LONG => $long, MOB_REQUEST_CLIENT_ID => $client_id, MOB_REQUEST_DRIVER_ID => "0", MOB_REQUEST_PICK_TIME => $time_of_pickup, MOB_REQUEST_STATUS => "0", MOB_REQUEST_OVER_STAT => "0", MOB_REQUEST_CANCLE => "0", MOB_DRIVER_PROFILE_IMAGE => $driver_profile_image);
            $response = array(STATUS => SUCCESS, MESSAGE => JOURNY_REQ_SUCCESS, DETAILS => $details);
        } else {
            $response = array(STATUS => FAIL, MESSAGE => JOURNY_REQ_FAIL);
        }
    } else {
        $response = array(STATUS => FAIL, MESSAGE => JOURNY_REQ_FAIL);
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response), JSON_PRETTY_PRINT);
}
?>