<?php

include_once './const.php';
include_once './config.php';
include_once './apns.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if ((!isset($_POST['client_id']) || empty($_POST['client_id'])) || (!isset($_POST['driver_id']) || empty($_POST['driver_id'])) || (!isset($_POST['lattitude']) || empty($_POST['lattitude'])) || (!isset($_POST['logitude']) || empty($_POST['logitude']))) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {

    $db_select = mysql_select_db(DB_DATABASE, $con);
    $client_id = $_POST['client_id'];
    $driver_id = $_POST['driver_id'];
    $lattitude = $_POST['lattitude'];
    $logitude = $_POST['logitude'];

    $driver = mysql_query("SELECT * from driver_data WHERE `driver_id`= {$driver_id}");
    $driver_response = mysql_fetch_assoc($driver);
    $driver_device_token = $driver_response['device_token'];
    $driver_device_token = str_replace(' ', '', $driver_device_token);
    if ($driver_response > 0) {

        $client_update = mysql_query("UPDATE " . REQUEST_DATA . " set `lattitude`={$lattitude}, `logitude`={$logitude},`drop_time`='1',`driver_id`={$driver_id} WHERE `client_id`={$client_id}");
        $client_affect = mysql_affected_rows();
        if ($client_affect > 0) {

            $message = array(
                'id' => '2',
                'client_id' => $client_id,
                'status' => 'succesfull',
                'message' => 'Drop off request successfull',
            );
            $objApns = new Apns_Client();
            $pushApns = $objApns->send_notification($driver_device_token, $message);
            $details = array('client_id' => $client_id, 'lattitude' => $lattitude, 'logitude' => $logitude);
            $response = array(STATUS => SUCCESS, MESSAGE => "Drop off request successfull", DETAILS => $details);
        } else {
            echo $response = array(STATUS => FAIL, MESSAGE => "Drop off request unsuccessfull ");
        }
    } else {
        echo $response = array(STATUS => FAIL, MESSAGE => "Request is already accepted");
    }
    echo json_encode($response);
}

    