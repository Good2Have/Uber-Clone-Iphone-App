<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if (!isset($_POST[MOB_REQUEST_RANDOM_ID]) || empty($_POST[MOB_REQUEST_RANDOM_ID])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);

    $trip_id = trim($_POST[MOB_REQUEST_RANDOM_ID]);
    $get_driver_info = mysql_query("SELECT driver_id, name,contact, lattitude, logitude, rating FROM " . DRIVER_DATA . " WHERE random_id = '$trip_id'");
    $check_count = mysql_num_rows($get_driver_info);
    $driver_id = "";
    $driver_name = "";
    $driver_contact = "";
    $driver_lat = "";
    $driver_long = "";
    $driver_rate = "";
    if ($check_count > 0) {
        while ($row = mysql_fetch_array($get_driver_info)) {
            $driver_id = $row['driver_id'];
            $driver_name = $row['name'];
            $driver_contact = $row['contact'];
            $driver_lat = $row['lattitude'];
            $driver_long = $row['logitude'];
            $driver_rate = $row['rating'];
        }
        switch ($driver_rate) {
            case ($driver_rate > 4): $driver_rate = 5;
                break;
            case ($driver_rate > 3): $driver_rate = 4;
                break;
            case ($driver_rate > 2): $driver_rate = 3;
                break;
            case ($driver_rate > 1): $driver_rate = 2;
                break;
            case ($driver_rate > 0): $driver_rate = 1;
                break;
            default: $driver_rate = 0;
        }
        /* $details = array(USER_ID => "$driver_id", MOB_DRIVER_NAME => "$driver_name", MOB_DRIVER_CONTACT => "$driver_contact", MOB_DRIVER_LAT => "$driver_lat", MOB_DRIVER_LONG => "$driver_long", MOB_DRIVER_RATE => "$driver_rate");
          $response = array(STATUS => SUCCESS, MESSAGE => DRIVER_INFO_SEND, DETAILS => $details); */
        $response = array(STATUS => SUCCESS, MESSAGE => DRIVER_INFO_SEND, USER_ID => "$driver_id", MOB_DRIVER_NAME => "$driver_name", MOB_DRIVER_CONTACT => "$driver_contact", MOB_DRIVER_LAT => "$driver_lat", MOB_DRIVER_LONG => "$driver_long", MOB_DRIVER_RATE => "$driver_rate");
    } else {
        /* $response = array(STATUS => FAIL, MESSAGE => DRIVER_INFO_NOT_SEND, DETAILS => $details); */
        $response = array(STATUS => FAIL, MESSAGE => DRIVER_INFO_NOT_SEND);
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>