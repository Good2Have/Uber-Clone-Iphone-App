<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if (!isset($_POST[MOB_DRIVER_ID]) || empty($_POST[MOB_DRIVER_ID]) || !isset($_POST[MOB_DRIVER_IS_BUSY]) || empty($_POST[MOB_DRIVER_IS_BUSY])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $driver_id = $_POST[MOB_DRIVER_ID];
    $is_busy = $_POST[MOB_DRIVER_IS_BUSY];
    $update_stat = mysql_query("UPDATE " . DRIVER_DATA . " SET is_busy='{$is_busy}'  WHERE driver_id='$driver_id'");
    $check_count = mysql_affected_rows();
    if ($check_count > 0) {
        if ($is_busy == 'no') {
            $update_stat = mysql_query("UPDATE " . DRIVER_DATA . " SET is_busy='{$is_busy}'  WHERE driver_id='$driver_id'");
            $response = array(STATUS => SUCCESS, MESSAGE => DRIVER_STATUS_CHANGE, MOB_DRIVER_IS_BUSY => $is_busy, MOB_DRIVER_BUSY_STA => AVAILABLE);
        } else {
            $update_stat = mysql_query("UPDATE " . DRIVER_DATA . " SET is_busy='{$is_busy}' WHERE driver_id='$driver_id'");
            $response = array(STATUS => SUCCESS, MESSAGE => DRIVER_STATUS_CHANGE, MOB_DRIVER_IS_BUSY => $is_busy, MOB_DRIVER_BUSY_STA => NOT_AVAILABLE);
        }
    } else {
        $response = array(STATUS => FAIL, MESSAGE => USER_NOT_FOUND);
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>