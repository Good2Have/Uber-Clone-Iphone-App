<?php

include_once './const.php';
include_once './config.php';
include_once './GCM.php';
include_once './apns_driver.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if (!isset($_POST[MOB_REQUEST_RANDOM_ID]) || empty($_POST[MOB_REQUEST_RANDOM_ID]) || !isset($_POST[MOB_REQUEST_LAT]) || empty($_POST[MOB_REQUEST_LAT]) || !isset($_POST[MOB_REQUEST_LONG]) || empty($_POST[MOB_REQUEST_LONG])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $trip_id = $_POST[MOB_REQUEST_RANDOM_ID];
    $end_lat = $_POST[MOB_REQUEST_LAT];
    $end_long = $_POST[MOB_REQUEST_LONG];
    $update_trip = mysql_query("UPDATE " . REQUEST_DATA . " SET complete_status='1',end_lat='$end_lat',end_long='$end_long' WHERE random_id='$trip_id'");
    $get_trip_data = mysql_query("SELECT * FROM " . REQUEST_DATA . " WHERE random_id='$trip_id'");
    $check_trip = mysql_num_rows($get_trip_data);
    if ($check_trip > 0) {
        $request_id = "";
        $raandom_id = "";
        $request_time = "";
        $lat = "";
        $long = "";
        $client_id = "";
        $driver_id = "";
        $pick_time = "";
        $req_stat = "";
        $comp_stat = "";
        $cancel_flg = "";
        while ($row = mysql_fetch_assoc($get_trip_data)) {
            $request_id = $row['request_id'];
            $raandom_id = $row['random_id'];
            $request_time = $row['request_time'];
            $lat = $row['lattitude'];
            $long = $row['logitude'];
            $client_id = $row['client_id'];
            $driver_id = $row['driver_id'];
            $pick_time = $row['time_of_pickup'];
            $req_stat = $row['request_status']; /* 0 no driver assign , 1 driver assign */
            $comp_stat = $row['complete_status']; /* 0 not completed , 1 completed */
            $cancel_flg = $row['cancel_flg']; /* 0 not cancled , 1 cancled */
        }
        $driver_count = "";
        $count_client_trip = mysql_query("SELECT COUNT(driver_id) AS total FROM " . REQUEST_DATA . " WHERE driver_id='$driver_id' GROUP BY driver_id");
        while ($row_client = mysql_fetch_assoc($count_client_trip)) {
            $driver_count = $row_client['total'];
        }
        $client_count = "";
        $count_driver_trip = mysql_query("SELECT COUNT(client_id) AS total FROM " . REQUEST_DATA . " WHERE client_id='$client_id' GROUP BY client_id");
        while ($row_driver = mysql_fetch_assoc($count_driver_trip)) {
            $client_count = $row_driver['total'];
        }
        $update_client = mysql_query("UPDATE " . CLIENT_DATA . " SET total_trips = '$client_count' WHERE client_id='$client_id'");
        $update_driver = mysql_query("UPDATE " . DRIVER_DATA . " SET is_on_root='0', total_trips = '$driver_count' WHERE driver_id='$driver_id'");
        $get_client = mysql_query("SELECT device_token, device_type FROM " . CLIENT_DATA . " WHERE client_id='$client_id'");
        $clientcount = mysql_num_rows($get_client);
        if ($clientcount > 0) {
            $cli_token = "";
            while ($row1 = mysql_fetch_assoc($get_client)) {
                $cli_token = $row1['device_token'];
                $cli_div_type = $row1['device_type'];
            }
            if ($cli_div_type == '0') {
                $gcm = new GCM();
                $registatoin_ids = array($cli_token);
                $message = array(STATUS => SUCCESS, MOB_REQUEST_RANDOM_ID => $raandom_id, MESSAGE => TRIP_FINISH_TO_CLIENT, 'id' => '2');
                $and_push = array("message" => $message);
                $gcm->send_notification($registatoin_ids, $and_push);
                $response = array(STATUS => SUCCESS, MESSAGE => TRIP_FINISH_TO_CLIENT, MOB_REQUEST_RANDOM_ID => $raandom_id);
            } else {
                $apns = new Apns_Driver();
                $cli_token = str_replace(' ', '', $cli_token);
                $message = array(STATUS => SUCCESS, MOB_REQUEST_RANDOM_ID => $raandom_id, MESSAGE => TRIP_FINISH_TO_CLIENT, 'id' => '3');
                $apns->send_notification($cli_token, $message);
                $update_status = mysql_query("UPDATE " . REQUEST_DATA . " SET complete_status='1' WHERE client_id='$client_id'");
                $response = array(STATUS => SUCCESS, MESSAGE => TRIP_FINISH_TO_CLIENT, MOB_REQUEST_RANDOM_ID => $raandom_id);
                
            }
        } else {
            $response = array(STATUS => FAIL, MESSAGE => USER_NOT_FOUND);
        }
    } else {
        $response = array(STATUS => FAIL, MESSAGE => TRIP_NOT_FOUND);
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>