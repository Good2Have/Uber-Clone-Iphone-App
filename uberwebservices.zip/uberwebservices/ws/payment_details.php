<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if (!isset($_POST[client_id]) || empty($_POST[client_id]) || !isset($_POST[amount]) || empty($_POST[amount]) || !isset($_POST[paypal_id]) || empty($_POST[paypal_id])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $client_id = $_POST['client_id'];
    $amount = $_POST['amount'];
    $paypal = $_POST['paypal_id'];
    $transaction_time = date('Y-m-d H:s:i');

    $insertPay = mysql_query("INSERT into payment(`client_id`,`amount`,`transaction_time`,`paypal_id`)VALUES({$client_id},'{$amount}','{$transaction_time}','{$paypal}')");
    if ($insertPay) {
        $check_count = mysql_insert_id();
        if ($check_count > 0) {

            $response = array(STATUS => SUCCESS, MESSAGE => "Payment Successfull");
        } else {
            $response = array(STATUS => FAIL, MESSAGE => "Payment Unsuccessfull");
        }
    } else {
        $response = array(STATUS => FAIL, MESSAGE => "Payment data is not correct");
    }

    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>