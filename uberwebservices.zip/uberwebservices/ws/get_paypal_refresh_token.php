<?php

include_once './const.php';
include_once './config.php';
include_once './paypal_functions.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
$response = "";

//CREATE CLASS OBJECT
$objPaypal = new paypalRequestManager();

if ((!isset($_POST['AUTHORIZATION_CODE']) || empty($_POST['AUTHORIZATION_CODE'])) ||
        (!isset($_POST['CLIENT_ID']) || empty($_POST['CLIENT_ID'])) ||
        (!isset($_POST['CORRELATION_ID']) || empty($_POST['CORRELATION_ID']))
) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $refresh_token = "";
    $paypal_access_token = "";
    //GET REFRESH TOKEN 
    $check_avaiailable = mysql_query("SELECT * FROM paypal_process_data  WHERE client_id = '" . $_POST['CLIENT_ID'] . "'");
    $check_count = mysql_num_rows($check_avaiailable);
    if ($check_count > 0) {

        while ($row = mysql_fetch_array($check_avaiailable)) {
            $refresh_token = $row['refresh_token'];
        }

        $response = array('refresh_token' => $refresh_token);
        //FINAL OUTPUT
        echo json_encode(array(JSON_ROOT_OBJECT => $response));
        exit();
    } else {
        $authorization_code = $_POST['AUTHORIZATION_CODE'];
        $refresh_token = $objPaypal->getRefreshToken($authorization_code);
        $response = array('refresh_token' => $refresh_token);
        $pos_user = mysql_query("INSERT INTO paypal_process_data (client_id, correlation_id, refresh_token) VALUES ('{$_POST['CLIENT_ID']}','{$_POST['CORRELATION_ID']}','{$refresh_token}')");
        if ($pos_user) {
            $insert_id = mysql_insert_id();
        }
    }

    //FINAL OUTPUT
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
    exit();
}



