<?php

/**
 * Database config variables
 */
/* local connection */
define("DB_HOST", "localhost");
define("DB_USER", "uber");
define("DB_PASSWORD", "uber@db@123");
define("DB_DATABASE", "uberdb");
date_default_timezone_set("" . DATE_FORMATE . "");
 define("GOOGLE_API_KEY", "AIzaSyCt6yvHeJwZj7vpp2nHKCQO76e7Hm_j9Kk"); /*DRIVER CLIENT API */

/* $con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
  $db_select = mysql_select_db(DB_DATABASE, $con);
 */
?>