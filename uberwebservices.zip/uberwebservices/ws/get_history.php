<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if (!isset($_POST[USER_ID]) || empty($_POST[USER_ID])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    if (!isset($_POST[IS_DRIVER]) || empty($_POST[IS_DRIVER])) {
        $is_driver = "0";
    } else {
        $is_driver = $_POST[IS_DRIVER];
    }
    $user_id = $_POST[USER_ID];

    if ($is_driver == 1) {
        $details = array();
        /* $check_id = mysql_query("SELECT random_id,lattitude,logitude,client_id,driver_id,time_of_pickup FROM " . REQUEST_DATA . " WHERE driver_id = '$user_id' AND complete_status='1' AND request_status='1' AND cancel_flg='0'"); */
        $check_id = mysql_query("SELECT "
                . "" . REQUEST_DATA . ".random_id, "
                . "" . REQUEST_DATA . ".lattitude, "
                . "" . REQUEST_DATA . ".logitude, "
                . "" . REQUEST_DATA . ".client_id, "
                . "" . REQUEST_DATA . ".driver_id, "
                . "" . REQUEST_DATA . ".time_of_pickup, "
                . "" . REQUEST_DATA . ".request_time AS " . MOB_REQUEST_TIME . ", "
                . "" . REQUEST_DATA . ".end_lat AS end_lattitude, "
                . "" . REQUEST_DATA . ".end_long AS end_logitude, "
                . "" . DRIVER_DATA . ".name AS 'driver_name', "
                . "" . CLIENT_DATA . ".name AS 'client_name' "
                . "FROM client_request_data "
                . "LEFT JOIN " . CLIENT_DATA . " ON " . REQUEST_DATA . ".client_id = " . CLIENT_DATA . ".client_id "
                . "LEFT JOIN " . DRIVER_DATA . " ON " . REQUEST_DATA . ".driver_id = " . DRIVER_DATA . ".driver_id "
                . "WHERE " . REQUEST_DATA . ".driver_id = '$user_id' "
                . "AND " . REQUEST_DATA . ".complete_status='1' "
                . "AND " . REQUEST_DATA . ".request_status='1' "
                . "AND " . REQUEST_DATA . ".cancel_flg='0'");
        $count1 = mysql_num_rows($check_id);
        if ($count1 > 0) {
            while ($count1 > 0) {
                $details[] = mysql_fetch_assoc($check_id);
                $count1--;
            }
            $response = array(STATUS => SUCCESS, MESSAGE => USER_HISTORY_SEND, DETAILS => $details);
        } else {
            $response = array(STATUS => FAIL, MESSAGE => USER_HISTORY_NOT_SEND, DETAILS => $details);
        }
    } else {
        $details = array();
        $check_id = mysql_query("SELECT random_id,lattitude,logitude,client_id,driver_id,time_of_pickup FROM " . REQUEST_DATA . " WHERE client_id = '$user_id' AND complete_status='1' AND request_status='1' AND cancel_flg='0'");
        $check_id = mysql_query("SELECT "
                . "" . REQUEST_DATA . ".random_id, "
                . "" . REQUEST_DATA . ".lattitude, "
                . "" . REQUEST_DATA . ".logitude, "
                . "" . REQUEST_DATA . ".client_id, "
                . "" . REQUEST_DATA . ".driver_id, "
                . "" . REQUEST_DATA . ".time_of_pickup, "
                . "" . REQUEST_DATA . ".request_time AS " . MOB_REQUEST_TIME . ", "
                . "" . REQUEST_DATA . ".end_lat AS end_lattitude, "
                . "" . REQUEST_DATA . ".end_long AS end_logitude, "
                . "" . CLIENT_DATA . ".name AS 'client_name', "
                . "" . DRIVER_DATA . ".name AS 'driver_name' "
                . "FROM client_request_data "
                . "LEFT JOIN " . CLIENT_DATA . " ON " . REQUEST_DATA . ".client_id = " . CLIENT_DATA . ".client_id "
                . "LEFT JOIN " . DRIVER_DATA . " ON " . REQUEST_DATA . ".driver_id = " . DRIVER_DATA . ".driver_id "
                . "WHERE " . REQUEST_DATA . ".client_id = '$user_id' "
                . "AND " . REQUEST_DATA . ".complete_status='1' "
                . "AND " . REQUEST_DATA . ".request_status='1' "
                . "AND " . REQUEST_DATA . ".cancel_flg='0'");
        $count1 = mysql_num_rows($check_id);
        if ($count1 > 0) {
            while ($count1 > 0) {
                $details[] = mysql_fetch_assoc($check_id);
                $count1--;
            }
            $response = array(STATUS => SUCCESS, MESSAGE => USER_HISTORY_SEND, DETAILS => $details);
        } else {
            $response = array(STATUS => FAIL, MESSAGE => USER_HISTORY_NOT_SEND, DETAILS => $details);
        }
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>