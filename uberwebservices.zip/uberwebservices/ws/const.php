<?php

define('DATE_FORMATE', 'America/Denver');
define('JSON_ROOT_OBJECT', 'uber_alpha');
define('STATUS', 'status');
define('MESSAGE', 'message');
define('SUCCESS', 'success');
define('FAIL', 'fail');

!defined("CATEGORY_PATH") ? define("CATEGORY_PATH", "upload/images/") : '';
define('PATH', 'http://192.168.0.130/employee_app/');
define('NOIMAGE', 'default.jpg');
define("SYSTEM_EMAIL_PASSWORD", "employee_app@elluminati.in");

/* database */
/* client_data */
define("CLIENT_DATA", "client_data");
/* table fields */
define("MOB_CLIENT_ID", "client_id");
define("MOB_CLIENT_NAME", "name");
define("MOB_CLIENT_EMAIL", "email");
define("MOB_CLIENT_GENDER", "gender");
define("MOB_CLIENT_PASS", "password");
define("MOB_CLIENT_CONTACT", "contact");
define("MOB_CLIENT_PHONE_CODE", "country_code");
define("MOB_CLIENT_DOB", "date_of_birth");
define("MOB_CLIENT_DEVICE_TOKEN", "device_token");
define("MOB_CLIENT_DEVICE_TYPE", "device_type");
define("MOB_CLIENT_REG_TIME", "reg_time");
define("MOB_CLIENT_LAT", "lattitude");
define("MOB_CLIENT_LON", "logitude");
define("MOB_CLIENT_PROFILE_IMAGE", "profile_image");

/* client_request_data */
define("REQUEST_DATA", "client_request_data");
/* table fields */
define("MOB_REQUEST_ID", "request_id");
define("MOB_REQUEST_RANDOM_ID", "random_id");
define("MOB_REQUEST_TIME", "request_time");
define("MOB_REQUEST_LAT", "lattitude");
define("MOB_REQUEST_LONG", "logitude");
define("MOB_REQUEST_CLIENT_ID", "client_id");
define("MOB_REQUEST_DRIVER_ID", "driver_id");
define("MOB_REQUEST_PICK_TIME", "time_of_pickup");
define("MOB_REQUEST_STATUS", "request_status");
define("MOB_REQUEST_OVER_STAT", "complete_status");
define("MOB_REQUEST_CANCLE", "cancel_flg");

/* driver_data */
define("DRIVER_DATA", "driver_data");
/* table fields */
define("MOB_DRIVER_ID", "driver_id");
define("MOB_DRIVER_NAME", "name");
define("MOB_DRIVER_EMAIL", "email");
define("MOB_DRIVER_PASS", "password");
define("MOB_DRIVER_CONTACT", "contact");
define("MOB_DRIVER_PHONE_CODE", "country_code");
define("MOB_DRIVER_DOB", "date_of_birth");
define("MOB_DRIVER_GENDER", "gender");
define("MOB_DRIVER_REF_NO", "reference_no");
define("MOB_DRIVER_LAT", "lattitude");
define("MOB_DRIVER_LONG", "logitude");
define("MOB_DRIVER_RATE", "rating");
define("MOB_DRIVER_RATE_COUNT", "rating_count");
define("MOB_DRIVER_CONF_STAT", "confirm_status");
define("MOB_DRIVER_DEVICE_TOKEN", "device_token");
define("MOB_DRIVER_DEVICE_TYPE", "device_type");
define("MOB_DRIVER_REG_TIME", "reg_time");
define("MOB_DRIVER_IS_BUSY", "is_busy");
define("MOB_DRIVER_BUSY_STA", "driver_busy_stat");
define("MOB_DRIVER_PROFILE_IMAGE", "profile_image");
define("MOB_DRIVER_RANDOM_ID", "random_id");

/* feedback_data */
define("FEEDBACK_DATA", "feedback_data");
/* table fields */
define("MOB_FEEDBACK_ID", "feedback_id");
define("MOB_FEEDBACK_REQ_ID", "request_id");
define("MOB_FEEDBACK_DRIVER_ID", "driver_id");
define("MOB_FEEDBACK_CLIENT_ID", "client_id");
define("MOB_FEEDBACK_TIME", "time");
define("MOB_FEEDBACK_RATE", "rating");
define("MOB_FEEDBACK_COMMENT", "comment");

define("DETAILS", "details");
define("IS_DRIVER", "is_driver");
define("USER_ID", "user_id");
define("AVAILABLE", "available");
define("NOT_AVAILABLE", "not_available");

/* messages */
define("NO_BLANK_FIELD_ALLOW", "Required field must not be blank."); /* if any service get required fields blank */
define("EMAL_ALREADY_REGISTERED", "Email already registered, please try another."); /* in register if email already registered driver_register.php & client_register.php */
define("USER_REG_FAIL", "User registration fail, please try again."); /* in register if email already registered. driver_register.php & client_register.php */
define("USER_REG_SUCCESS", "User successfully registered."); /* when user successfully registered. */
define("USER_NOT_FOUND", "No registered user found, please register first."); /* in login when user not found. login.php */
define("USER_NOT_CONFIRM", "User was not confirm by admin."); /* while login confirm user not found. login.php */
define("USER_SUCCESS_LOGIN", "Login successfully."); /* when user successfully logged in. login.php */
define("USER_PROFILE_SEND", "User profile successfully send."); /* when user successfully logged in. login.php */
define("JOURNY_REQ_SUCCESS", "Request successfully submitted."); /* when client request successfully submited. client_pick_request.php */
define("JOURNY_REQ_FAIL", "Request submission fail, please try again."); /* when client request successfully not submited. client_pick_request.php */
define("TRIP_TIME_SUCCESS_SET", "Service time successfully set for service."); /* when pick-up time successfully set by driver. set_pick_time.php */
define("TRIP_TIME_NOT_SET", "Service time not set, please try again."); /* when pick-up time successfully not set by driver. set_pick_time.php */
define("TRIP_CLIENT_NOT_FOUND", "Sorry, trip generator was not found."); /* when trip generator not found. set_pick_time.php */
define("TRIP_NOT_FOUND", "Sorry, trip was not found."); /* when trip not found. set_pick_time.php */
define("DRIVER_POS_UPDATED", "Driver Position updated successfully."); /* any how when driver location service is called. set_driver_location.php */
define("DRIVER_POS_UPDATED_O", "Driver Position already updated."); /* any how when driver location service is called. set_driver_location.php */
define("DRIVER_POS_UPDATED_FAIL", "Driver Position Update fail."); /* any how when driver location service is called. set_driver_location.php */
define("TRIP_FINISH_TO_CLIENT", "Trip was successfully over."); /* any how when driver location service is called. set_driver_location.php */
define("RATE_NOT_FOUND", "No rating found."); /* any how when driver location service is called. set_driver_location.php */
define("RATE_DONE", "Rating process completed successfully."); /* any how when driver location service is called. set_driver_location.php */
define("USER_PRO_UPDATED", "User details successfully updated."); /* when user details successfully changed in edit_profile.php */
define("USER_HISTORY_SEND", "User history successfully send."); /* when user details successfully changed in edit_profile.php */
define("USER_HISTORY_NOT_SEND", "No history available."); /* when user details successfully changed in edit_profile.php */
define("OPERATOR_NUMBER_SEND", "Operator number sent successfully."); /* when operator number successfully send by get_operator.php */
define("NO_OPERATOR_NUMBER", "Operator number not sent successfully."); /* when operator number not successfully send by get_operator.php */
define("DRIVER_STATUS_CHANGE", "Driver availability successfully changed."); /* when driver availablity changed in set_driver_stat.php */
define("REQ_ASS_DRI", "A request is assign to you.");
define("REQ_ASS_DEL", "A request was terminated by admin, Please try again...");
define("JOB_DONE", "Job was completed.");
define("PICKUP_TIME_MSG", "Root Pickup time by Driver.");
define("REACHED_TIME_UPDATE", "Driver reached time was updated successfully."); /* driver reached time is updated using driver_reached_client.php */
define("REACHED_TIME_NOT_UPDATE", "Driver reached time was not updated."); /* driver reached time is updated using driver_reached_client.php */
define("DRIVER_INFO_SEND", "Driver data successfully send."); /* driver reached time is updated using get_driver_location.php */
define("DRIVER_INFO_NOT_SEND", "Driver data not send."); /* driver reached time is updated using get_driver_location.php */
define("DRIVER_REACHED_TO_CLIENT", "Driver reached to you."); /* push message while driver reached to client palce in driver_reached_client.php */

define("REFRESH_TOKEN", "refresh_token");
define("CLIENT_ID", "client_id");
define("CORRELATION_ID", "correlation_id");
?>