<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
$db_select = mysql_select_db(DB_DATABASE, $con);
$details = array();
$check_id = mysql_query("SELECT operator AS operator FROM operator_no LIMIT 1");
$count1 = mysql_num_rows($check_id);
if ($count1 > 0) {
    while ($count1 > 0) {
        $details[] = mysql_fetch_assoc($check_id);
        $count1--;
    }
    $response = array(STATUS => SUCCESS, MESSAGE => OPERATOR_NUMBER_SEND, DETAILS => $details);
} else {
    $response = array(STATUS => FAIL, MESSAGE => NO_OPERATOR_NUMBER, DETAILS => $details);
}
echo json_encode(array(JSON_ROOT_OBJECT => $response));
?>