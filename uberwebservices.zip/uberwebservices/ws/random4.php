<?php

function my_random4_number() {
    $min = 1;
    $max = 9;
    $random_number1 = rand($min, $max);


    //first capital  
    $length = 1;

    $chars = 'ABCDEFGHJKLMNOPQRSTUVWXYZ';
    $count = mb_strlen($chars);

    for ($i = 0, $result = ''; $i < $length; $i++) {
        $index = rand(0, $count - 1);
        $result .= mb_substr($chars, $index, 1);
    }


    //second  capital                  


    $chars1 = 'ABCDEFGHJKLMNOPQRSTUVWXYZ';
    $count = mb_strlen($chars1);

    for ($i = 0, $result1 = ''; $i < $length; $i++) {
        $index = rand(0, $count - 1);
        $result1 .= mb_substr($chars1, $index, 1);
    }


    //first small           


    $smallch = 'abcdefghijkmnopqrstuvwxyz';
    $counts = mb_strlen($smallch);

    for ($i = 0, $smallchar = ''; $i < $length; $i++) {
        $index = rand(0, $counts - 1);
        $smallchar .= mb_substr($smallch, $index, 1);
    }

    //second small    

    $smallch2 = 'abcdefghijkmnopqrstuvwxyz';
    $counts2 = mb_strlen($smallch2);

    for ($i = 0, $smallchar2 = ''; $i < $length; $i++) {
        $index = rand(0, $counts - 1);
        $smallchar2 .= mb_substr($smallch2, $index, 1);
    }


    $special = array("$","@");
    $spe_random = rand(0, 1);
    $spe = $special[$spe_random];

    $rnd = $random_number1;

    $main_no = "";

    if ($random_number1 % 2 == 0) {
        if ($random_number1 == 2) {

            $main_no = $result . $smallchar . $rnd . $smallchar2;
        }
        if ($random_number1 == 4) {
            $main_no = $result . $rnd . $result1 . $smallchar;
        }

        if ($random_number1 == 6) {
            $main_no = $smallchar . $spe . $result . $result1;
        }
        if ($random_number1 == 8) {
            $main_no = $spe . $rnd . $result . $result1;
        }
    }

    if ($random_number1 % 2 != 0) {
        if ($random_number1 == 1) {

            $main_no = $result . $spe . $rnd . $result1;
        }

        if ($random_number1 == 3) {
            $main_no = $smallchar . $rnd . $result . $smallchar2;
        }

        if ($random_number1 == 5) {
            $main_no = $spe . $smallchar2 . $result . $smallchar;
        }
        if ($random_number1 == 7) {
            $main_no = $rnd . $result . $spe . $smallchar;
        }
        if ($random_number1 == 9) {
            $main_no = $result . $smallchar . $spe . $rnd;
        }
    }
    return $main_no;
    //echo "<br><br><br>r1-".$random_number1;
}

my_random4_number();
?>