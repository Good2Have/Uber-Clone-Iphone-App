<?php

include_once './const.php';
include_once './config.php';

function unique($use = "") {
    $mt = str_replace(".", "", str_replace(" ", "", microtime()));
    $unique = substr(number_format($mt * rand(), 0, '', ''), 0, 10);
    return $unique;
}

if (!file_exists($_FILES["image_upload"]["name"]) && $_FILES["image_upload"]["size"] == "") {
    
} else {
    $imageName = $_FILES["image_upload"]["name"];
    $imageTmpLoc = $_FILES["image_upload"]["tmp_name"];
    $imageNamePath = unique() . $imageName;
    $imagepathAndName = "../uploads/" . $imageNamePath;
    if (file_exists($imagepathAndName)) {
        
    } else {
        if (move_uploaded_file($_FILES["image_upload"]["tmp_name"], $imagepathAndName)) {
            
        } else {
            
        }
    }
// Evaluate the value returned from the function if needed
    if ($imagemoveResult) {
        
    }
}

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if ((!isset($_POST[MOB_CLIENT_NAME]) || empty($_POST[MOB_CLIENT_NAME])) || (!isset($_POST[MOB_CLIENT_EMAIL]) || empty($_POST[MOB_CLIENT_EMAIL])) || (!isset($_POST[MOB_CLIENT_PASS]) || empty($_POST[MOB_CLIENT_PASS])) || (!isset($_POST[MOB_CLIENT_CONTACT]) || empty($_POST[MOB_CLIENT_CONTACT])) || (!isset($_POST[MOB_CLIENT_DEVICE_TOKEN]) || empty($_POST[MOB_CLIENT_DEVICE_TOKEN]))) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);

    $name = ucwords(trim($_POST[MOB_CLIENT_NAME]));
    $email = $_POST[MOB_CLIENT_EMAIL];
    $password = $_POST[MOB_CLIENT_PASS];
    $contact = $_POST[MOB_CLIENT_CONTACT];
    $phone_code = "";
    if (!isset($_POST[MOB_CLIENT_PHONE_CODE]) || empty($_POST[MOB_CLIENT_PHONE_CODE])) {
        $phone_code = "0";
    } else {
        $phone_code = $_POST[MOB_CLIENT_PHONE_CODE];
    }
    $token = $_POST[MOB_CLIENT_DEVICE_TOKEN];
    $device_type = $_POST[MOB_CLIENT_DEVICE_TYPE];
    $country_code = $_POST[MOB_CLIENT_PHONE_CODE];
    $latitude = $_POST[MOB_CLIENT_LAT];
    $longitude = $_POST[MOB_CLIENT_LON];
    if ($device_type == '0' || $device_type == 'android') {
        $device_type = '0';
    } else {
        $device_type = '1';
    }
    $dateNow = date('Y-m-d H:i:s', time());

    $check_avaiailable = mysql_query("SELECT * FROM " . CLIENT_DATA . " WHERE email = '" . $email . "'");
    $check_count = mysql_num_rows($check_avaiailable);
    if ($check_count > 0) {
        $response = array(STATUS => FAIL, MESSAGE => EMAL_ALREADY_REGISTERED);
    } else {
        $reg_user = mysql_query("INSERT INTO " . CLIENT_DATA . "(name, email, password, contact, device_token, device_type, reg_time,country_code,lattitude,logitude,profile_image) VALUES ('$name','$email','$password','$contact','$token','$device_type','$dateNow','$phone_code','$latitude','$longitude','$imageNamePath')");
        if ($reg_user) {
            $insert_id = mysql_insert_id();
            $details = array();
            if ($insert_id > 0) {
                $details = array(MOB_CLIENT_ID => "" . $insert_id, MOB_CLIENT_NAME => $name, MOB_CLIENT_EMAIL => $email, MOB_CLIENT_CONTACT => $contact, MOB_CLIENT_REG_TIME => $dateNow, MOB_CLIENT_PHONE_CODE => "" . $phone_code, MOB_CLIENT_LAT => "" . $latitude, MOB_CLIENT_LON => "" . $longitude, MOB_CLIENT_PROFILE_IMAGE => "" . $imageNamePath);
                $response = array(STATUS => SUCCESS, MESSAGE => USER_REG_SUCCESS, DETAILS => $details);
            } else {
                $response = array(STATUS => FAIL, MESSAGE => USER_REG_FAIL);
            }
        } else {
            $response = array(STATUS => FAIL, MESSAGE => USER_REG_FAIL);
        }
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>