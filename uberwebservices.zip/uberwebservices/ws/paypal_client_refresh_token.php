<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
$response = "";

if ((!isset($_POST['CLIENT_ID']) || empty($_POST['CLIENT_ID']))
) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $client_id = $_POST['CLIENT_ID'];
    $client_data = mysql_query("SELECT * FROM paypal_process_data  WHERE client_id = '" . $_POST['CLIENT_ID'] . "'");
    $client_count = mysql_num_rows($client_data);
    if ($client_count > 0) {
        $client_response = mysql_fetch_assoc($client_data);
        $client_refresh_token = $client_response['refresh_token'];
        $client_correlation_id = $client_response['correlation_id'];
        $response = array(STATUS => SUCCESS, 'refresh_token' => $client_refresh_token, 'client_correlation_id' => $client_correlation_id);

        echo json_encode(array(JSON_ROOT_OBJECT => $response));
        exit();
    } else {
        $response = array(STATUS => FAIL, 'refresh_token' => 'Refresh token is NULL');
        echo json_encode(array(JSON_ROOT_OBJECT => $response));
        exit();
    }
//FINAL OUTPUT
    $response = array(STATUS => FAIL, 'refresh_token' => "Refresh token is NULL");
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
    exit();
}

