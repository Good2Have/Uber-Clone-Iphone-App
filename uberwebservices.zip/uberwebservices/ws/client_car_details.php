<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if (!isset($_POST['client_id'])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $client_id = $_POST['client_id'];
    $car_select = mysql_query("SELECT * from car_details WHERE `client_id`={$client_id}");
    $car_response = mysql_fetch_assoc($car_select);
    $car_color = $car_response['car_color'];
    $car_model = $car_response['car_model'];
    $year_of_registration = $car_response['year_of_registration'];
    $car_number_plate = $car_response['car_number_plate'];
    if ($car_response > 0) {
        $details = array('client_id' => "" . $client_id, 'car_color' => "" . $car_color, 'car_model' => "" . $car_model, 'year_of_registration' => "" . $year_of_registration, 'car_number_plate' => "" . $car_number_plate);
        $response = array(STATUS => SUCCESS, MESSAGE => "Client Car Information", DETAILS => $details);
    } else {
        echo $response = array(STATUS => FAIL, MESSAGE => "Client Id not found in the database");
    }

    echo json_encode($response);
}

    