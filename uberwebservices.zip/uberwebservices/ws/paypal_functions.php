<?php

/**
 * this class is for manage all paypal requests
 */
class paypalRequestManager {

    protected $client_id;
    protected $secret;
    public $liveApiUrl;
    public $sandboxApiUrl;
    public $authorization_code;
    public $accessToken;
    public $refreshToken;
    public $paymentUrl;

    /**
     * Class constructor.
     */
    function __construct() {
        $this->client_id = "ASR0bxDIAqjAPLLlPs_echPOSIloTtvLdcQFNelhseLzNKcyqojUdMPOxxOZ";
        $this->secret = "EOA04BCTQwDD7qwZKMT7B1caV-POYSBweJ0QDjW3ld0cEgL9lAMojpJVQTw2";
        $this->liveApiUrl = 'https://api.paypal.com/v1/oauth2/token';
        $this->sandboxApiUrl = 'https://api.sandbox.paypal.com/v1/oauth2/token'; // sandbox paypal
        $this->paymentUrl = 'https://api.sandbox.paypal.com/v1/payments/payment';
    }

    function httpGet($url) {
        // Assigning cURL options to an array
        $options = Array(
            CURLOPT_RETURNTRANSFER => TRUE, // Setting cURL's option to return the webpage data
            CURLOPT_FOLLOWLOCATION => TRUE, // Setting cURL to follow 'location' HTTP headers
            CURLOPT_AUTOREFERER => TRUE, // Automatically set the referer where following 'location' HTTP headers
            CURLOPT_SSL_VERIFYPEER => FALSE,
            CURLOPT_SSL_VERIFYHOST => FALSE,
            CURLOPT_CONNECTTIMEOUT => 120, // Setting the amount of time (in seconds) before the request times out
            CURLOPT_TIMEOUT => 120, // Setting the maximum amount of time for cURL to execute queries
            CURLOPT_MAXREDIRS => 10, // Setting the maximum number of redirections to follow
            CURLOPT_USERAGENT => "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1a2pre) Gecko/2008073000 Shredder/3.0a2pre ThunderBrowse/3.2.1.8", // Setting the useragent
            CURLOPT_URL => $url, // Setting cURL's URL option with the $url variable passed into the function
        );

        $ch = curl_init();  // Initialising cURL
        curl_setopt_array($ch, $options);   // Setting cURL's options using the previously assigned array data in $options
        $data = curl_exec($ch); // Executing the cURL request and assigning the returned data to the $data variable
        curl_close($ch);    // Closing cURL
        return $data;   // Returning the data from the function
    }

    function httpPost($url, $params) {
        $postData = '';
        //create name value pairs seperated by &
        foreach ($params as $k => $v) {
            $postData .= $k . '=' . $v . '&';
        }
        rtrim($postData, '&');

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $this->sandboxApiUrl);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, $this->client_id . ":" . $this->secret);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

        $output = curl_exec($ch);

        if ($output === false) {
            echo "Error Number:" . curl_errno($ch) . "<br>";
            echo "Error String:" . curl_error($ch);

            //die();
        }
        curl_close($ch);
        return $output;
    }

    function debug($data) {
        echo '<pre>';
        print_r($data);
        echo '</pre>';
    }

    // GET REFRESH TOKEN
    function getRefreshToken($authorization_code) {

        $url = $this->sandboxApiUrl; // sandbox paypal
//        $authorization_code = 'ECI1VqsaqV9fC-yIncezuqTMF7XDp3I4_fpmwwDi2vEYnZcSRWXs2-_WmV8ASMNpH0HfRBe78LINhBCyJ2XLiGFSPVDSaaEA8DBR_dY64_p_UF0XeRRGPz8F6cTFISkFx-PFscc1ORzCQbofLrPFkec';
        $params = array('grant_type' => 'authorization_code',
            'response_type' => 'token',
            'redirect_uri' => 'urn:ietf:wg:oauth:2.0:oob',
            'code' => $authorization_code);


        $jsonData = $this->httpPost($url, $params);
        $jsonDecodeValue = json_decode($jsonData);
        return $jsonDecodeValue->refresh_token;
    }

    // GET ACCESS TOKEN FROM REFRESH TOKEN
    function getAccessToken($refreshToken) {

        $url = $this->sandboxApiUrl; // sandbox paypal
//        $refreshToken = 'A015p3xyhjByVhldEbd58J7h8m3D2lTjj5.2vd3r4ZXAbrk';
        $params = array('grant_type' => 'refresh_token&refresh_token=' . $refreshToken
        );

        $jsonData = $this->httpPost($url, $params);
        $jsonDecodeValue = json_decode($jsonData);
        return $jsonDecodeValue->access_token;
    }

    // THIS FUNCTION IS USED FOR MAKE PAYMENT
    function make_post_call($url, $postdata, $accessToken, $correlationId) {
//                global $token;               
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'PayPal-Client-Metadata-Id:' . $correlationId,
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json'
        ));
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
        #curl_setopt($curl, CURLOPT_VERBOSE, TRUE);
        $response = curl_exec($curl);
        if (empty($response)) {
            echo 'response is empty';
            // some kind of an error happened
            die(curl_error($curl));
            curl_close($curl); // close cURL handler
        } else {
            $info = curl_getinfo($curl);
            //echo "Time took: " . $info['total_time']*1000 . "ms\n";
            curl_close($curl); // close cURL handler
            if ($info['http_code'] != 200 && $info['http_code'] != 201) {
                echo "Received error: " . $info['http_code'] . "\n";
                echo "Raw response:" . $response . "\n";
                die();
            }
        }
        // Convert the result from JSON format to a PHP array
        $jsonResponse = json_decode($response, TRUE);
        return $jsonResponse;
    }

}

/* * ######################################################################## */

/* * ******************************************************* */
//This part is for demonstrate  how to use functions
/* * ******************************************************* */

/*
  $objPaypalRequestManager = new paypalRequestManager();


  // GET REFRESH TOKEN
  //$data = $objPaypalRequestManager->getRefreshToken($authorization_code);

  /******************************** */
//credit card payment sample data
/* * ***************************** */
$postdata = '{
  "intent":"sale",
  "payer":{
    "payment_method":"credit_card",
    "funding_instruments":[
      {
        "credit_card":{
          "number":"4417119669820331",
          "type":"visa",
          "expire_month":11,
          "expire_year":2018,
          "cvv2":"874",
          "first_name":"Betsy",
          "last_name":"Buyer",
          "billing_address":{
            "line1":"111 First Street",
            "city":"Saratoga",
            "state":"CA",
            "postal_code":"95070",
            "country_code":"US"
          }
        }
      }
    ]
  },
  "transactions":[
    {
      "amount":{
        "total":"7.47",
        "currency":"USD",
        "details":{
          "subtotal":"7.41",
          "tax":"0.03",
          "shipping":"0.03"
        }
      },
      "description":"This is the payment transaction description."
    }
  ]
}';

//echo'<pre>';print_r(json_decode($postdata,true));echo'</pre>';
/* * ****************************** */
//            end
/* * ***************************** */

/* ###################################################### */

/* * ****************************** */
//paypal payment sample data
/* * ***************************** */

$postPlayplaData = '{
  "intent":"authorize",
  "redirect_urls":{
    "return_url":"http://uber.globusapps.com/ws",
    "cancel_url":"http://uber.globusapps.com/ws"
  },
  "payer":{
    "payment_method":"paypal"
  },
  "transactions":[
    {
      "amount":{
        "total":"7.47",
        "currency":"USD"
      },
      "description":"This is the payment transaction description."
    }
  ]
}';
/*********************************/
//            end
/********************************/
/*
$refreshToken = 'uDqdZo2uFY_F1bRwWyP37LsqPnT58OwkAAfSIPTNLcJnLDEGaPwK4nAm9geS-LCdUVIOvMGMUrLTfOlX3erPspBS8rg';
$correlationId = '0aa67dcdbdca40839755799bdd917042';

// get access token 
// this function is called every time for payment process*/
//$accessToken = $objPaypalRequestManager->getRefreshToken($refreshToken);  


//make payment with payment_method paypal 
//$datapost = $objPaypalRequestManager->make_post_call($objPaypalRequestManager->paymentUrl, $postPlayplaData,$accessToken,$correlationId);
/*
//make payment with payment_method credit_card
$datapost = $objPaypalRequestManager->make_post_call($objPaypalRequestManager->paymentUrl, $postPlayplaData,$accessToken,$correlationId);

*
$objPaypalRequestManager->debug($accessToken);
$objPaypalRequestManager->debug($datapost);
*/
/**********************************************************/
                        //END
/**********************************************************/
