<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if (!isset($_POST[USER_ID]) || empty($_POST[USER_ID])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    if (!isset($_POST[IS_DRIVER]) || empty($_POST[IS_DRIVER])) {
        $is_driver = "0";
    } else {
        $is_driver = $_POST[IS_DRIVER];
    }
    $user_id = $_POST[USER_ID];

    if ($is_driver == 1) {
        $check_id = mysql_query("SELECT * FROM " . DRIVER_DATA . " WHERE driver_id = '$user_id'");
        $count1 = mysql_num_rows($check_id);
        if ($count1 > 0) {
            $update_profile = " UPDATE " . DRIVER_DATA . " SET driver_id='$user_id'";
            if (!isset($_POST[MOB_CLIENT_NAME]) || empty($_POST[MOB_CLIENT_NAME])) {
                
            } else {
                $name = ucwords($_POST[MOB_CLIENT_NAME]);
                $update_profile .= ",name = '$name'";
            }
            if (!isset($_POST[MOB_DRIVER_PHONE_CODE]) || empty($_POST[MOB_DRIVER_PHONE_CODE])) {
                
            } else {
                $phone_code = $_POST[MOB_DRIVER_PHONE_CODE];
                $update_profile .= ",country_code = '$phone_code'";
            }
            if (!isset($_POST[MOB_CLIENT_GENDER]) || empty($_POST[MOB_CLIENT_GENDER])) {
                
            } else {
                $gender = ucwords($_POST[MOB_CLIENT_GENDER]);
                $update_profile .= ",gender = '$gender'";
            }
            if (!isset($_POST[MOB_CLIENT_CONTACT]) || empty($_POST[MOB_CLIENT_CONTACT])) {
                
            } else {
                $contact = $_POST[MOB_CLIENT_CONTACT];
                $update_profile .= ",contact = '$contact'";
            }
            if (!isset($_POST[MOB_CLIENT_DOB]) || empty($_POST[MOB_CLIENT_DOB])) {
                
            } else {
                $dob = $_POST[MOB_CLIENT_DOB];
                $update_profile .= ",date_of_birth = '$dob'";
            }
            if (!isset($_POST[MOB_CLIENT_PASS]) || empty($_POST[MOB_CLIENT_PASS])) {
                
            } else {
                $pass = $_POST[MOB_CLIENT_PASS];
                $update_profile .= ",password = '$pass'";
            }
            $update_profile .= " WHERE driver_id='$user_id' ";
            $result = mysql_query($update_profile);
            $check_avaiailable = mysql_query("SELECT * FROM " . DRIVER_DATA . " WHERE driver_id = '$user_id'");
            $check_count = mysql_num_rows($check_avaiailable);
            if ($check_count > 0) {
                $details = array();
                while ($row = mysql_fetch_array($check_avaiailable)) {
                    $user_id = $row['driver_id'];
                    $name = $row['name'];
                    $email = $row['email'];
                    $contact = $row['contact'];
                    $phone_code= $row['country_code'];
                    $gender = $row['gender'];
                    $dob = $row['date_of_birth'];
                    $ref_no = $row['reference_no'];
                    $let = $row['lattitude'];
                    $long = $row['logitude'];
                    $rating = $row['rating'];
                    $rate_count = $row['rating_count'];
                    $conf_stat = $row['confirm_status'];
                    $reg_time = $row['reg_time'];
                }
                if ($conf_stat == '1') {
                    $details = array(MOB_DRIVER_ID => "" . $user_id, MOB_DRIVER_NAME => $name, MOB_DRIVER_EMAIL => $email, MOB_DRIVER_CONTACT => $contact, MOB_DRIVER_DOB => $dob, MOB_DRIVER_GENDER => "" . $gender, MOB_DRIVER_REF_NO => $ref_no, MOB_DRIVER_LAT => $let, MOB_DRIVER_LONG => $long, MOB_DRIVER_RATE => "" . $rating, MOB_DRIVER_RATE_COUNT => "" . $rate_count, MOB_DRIVER_CONF_STAT => "" . $conf_stat, MOB_DRIVER_REG_TIME => $reg_time, MOB_DRIVER_PHONE_CODE => "" . $phone_code);
                    $response = array(STATUS => SUCCESS, MESSAGE => USER_PRO_UPDATED, DETAILS => $details);
                } else {
                    $response = array(STATUS => FAIL, MESSAGE => USER_NOT_CONFIRM);
                }
            } else {
                $response = array(STATUS => FAIL, MESSAGE => USER_NOT_FOUND);
            }
        } else {
            $response = array(STATUS => FAIL, MESSAGE => USER_NOT_FOUND);
        }
    } else {
        $check_id = mysql_query("SELECT * FROM " . CLIENT_DATA . " WHERE client_id = '$user_id'");
        $count1 = mysql_num_rows($check_id);
        if ($count1 > 0) {
            $update_profile = " UPDATE " . CLIENT_DATA . " SET client_id='$user_id'";
            if (!isset($_POST[MOB_CLIENT_NAME]) || empty($_POST[MOB_CLIENT_NAME])) {
                
            } else {
                $name = ucwords($_POST[MOB_CLIENT_NAME]);
                $update_profile .= ",name = '$name'";
            }
            if (!isset($_POST[MOB_CLIENT_PHONE_CODE]) || empty($_POST[MOB_CLIENT_PHONE_CODE])) {
                
            } else {
                $phone_code = $_POST[MOB_CLIENT_PHONE_CODE];
                $update_profile .= ",country_code = '$phone_code'";
            }
            if (!isset($_POST[MOB_CLIENT_GENDER]) || empty($_POST[MOB_CLIENT_GENDER])) {
                
            } else {
                $gender = ucwords($_POST[MOB_CLIENT_GENDER]);
                $update_profile .= ",gender = '$gender'";
            }
            if (!isset($_POST[MOB_CLIENT_CONTACT]) || empty($_POST[MOB_CLIENT_CONTACT])) {
                
            } else {
                $contact = $_POST[MOB_CLIENT_CONTACT];
                $update_profile .= ",contact = '$contact'";
            }
            if (!isset($_POST[MOB_CLIENT_DOB]) || empty($_POST[MOB_CLIENT_DOB])) {
                
            } else {
                $dob = $_POST[MOB_CLIENT_DOB];
                $update_profile .= ",date_of_birth = '$dob'";
            }
            if (!isset($_POST[MOB_CLIENT_PASS]) || empty($_POST[MOB_CLIENT_PASS])) {
                
            } else {
                $pass = $_POST[MOB_CLIENT_PASS];
                $update_profile .= ",password = '$pass'";
            }
            $update_profile .= " WHERE client_id='$user_id' ";
            $result = mysql_query($update_profile);
            $check_avaiailable = mysql_query("SELECT * FROM " . CLIENT_DATA . " WHERE client_id = '$user_id'");
            $check_count = mysql_num_rows($check_avaiailable);
            if ($check_count > 0) {
                $details = array();
                while ($row = mysql_fetch_array($check_avaiailable)) {
                    $user_id = $row['client_id'];
                    $name = $row['name'];
                    $email = $row['email'];
                    $contact = $row['contact'];
                    $phone_code= $row['country_code'];
                    $dob = $row['date_of_birth'];
                    $gender = $row['gender'];
                    $reg_time = $row['reg_time'];
                }
                $details = array(MOB_CLIENT_ID => "" . $user_id, MOB_CLIENT_NAME => $name, MOB_CLIENT_EMAIL => $email, MOB_CLIENT_CONTACT => $contact, MOB_CLIENT_DOB => $dob, MOB_CLIENT_GENDER => "" . $gender, MOB_CLIENT_REG_TIME => $reg_time, MOB_CLIENT_PHONE_CODE => "" . $phone_code);
                $response = array(STATUS => SUCCESS, MESSAGE => USER_PRO_UPDATED, DETAILS => $details);
            } else {
                $response = array(STATUS => FAIL, MESSAGE => USER_NOT_FOUND);
            }
        } else {
            $response = array(STATUS => FAIL, MESSAGE => USER_NOT_FOUND);
        }
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>