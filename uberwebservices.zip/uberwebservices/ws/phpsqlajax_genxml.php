<?php

/*require("./const.php");
require("./config.php");*/
function parseToXML($htmlStr) {
    $xmlStr = str_replace('<', '&lt;', $htmlStr);
    $xmlStr = str_replace('>', '&gt;', $xmlStr);
    $xmlStr = str_replace('"', '&quot;', $xmlStr);
    $xmlStr = str_replace("'", '&#39;', $xmlStr);
    $xmlStr = str_replace("&", '&amp;', $xmlStr);
    return $xmlStr;
}

// Opens a connection to a MySQL server
/*$connection = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
if (!$connection) {
    die('Not connected : ' . mysql_error());
}

// Set the active MySQL database
$db_selected = mysql_select_db(DB_DATABASE, $connection);
if (!$db_selected) {
    die('Can\'t use db : ' . mysql_error());
}
*/
// Select all the rows in the markers table
/*$query = "SELECT * FROM client_request_data WHERE driver_id='0' AND request_status='0' AND cancel_flg='0'";
$result = mysql_query($query);
if (!$result) {
    die('Invalid query: ' . mysql_error());
}
*/
header("Content-type: text/xml");

// Start XML file, echo parent node
echo '<markers>';

// Iterate through the rows, printing XML nodes for each
while ($row = @mysql_fetch_assoc($result)) {
    // ADD TO XML DOCUMENT NODE
    echo '<marker ';
    echo 'name="' . parseToXML($row['random_id']) . '" ';
    echo 'address="' . parseToXML($row['random_id']) . '" ';
    echo 'lat="' . $row['lattitude'] . '" ';
    echo 'lng="' . $row['logitude'] . '" ';
    echo 'type="client" ';
    echo '/>';
}

// End XML file
echo '</markers>';
?>
