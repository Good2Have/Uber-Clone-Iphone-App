<!DOCTYPE html>
<html>
<body>

<form action="driver_register.php?contact=1234&country_code=%2B91&device_token=IOS_SIMULATOR&device_type=1&email=vinayaka@40yahoo.com&lattitude=0.000000&logitude=0.000000&name=sahu&password=1234" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="image_upload" id="image_upload">
    <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html> 