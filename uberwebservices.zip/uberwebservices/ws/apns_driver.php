<?php

// Push Notification for Client
error_reporting(true);

class Apns_Driver {

    public $ctx;
    public $fp;
    private $ssl = 'ssl://gateway.push.apple.com:2195';
    private $passphrase = "";
    private $sandboxCertificate = 'apns-devd.pem';
    private $sandboxSsl = 'ssl://gateway.sandbox.push.apple.com:2195';
    private $sandboxFeedback = 'ssl://feedback.sandbox.push.apple.com:2196';
    private $message = "ManagerMaster";

    public function __construct() {
        $this->initialize_apns();
    }

    public function initialize_apns() {
        $this->ctx = stream_context_create();
        stream_context_set_option($this->ctx, 'ssl', 'local_cert', $this->sandboxCertificate);
        stream_context_set_option($this->ctx, 'ssl', 'passphrase', $this->passphrase); // use this if you are using a passphrase
        $this->fp = @stream_socket_client(
                        $this->sandboxSsl, $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $this->ctx);
        if ($this->fp) {
            
        } else {
            
        }
    }

    public function send_notification($token, $message) {
        $errCounter = 0;
        if (!isset($message["id"]) || empty($message["id"])) {
            $id = "0";
        } else {
            $id = $message["id"];
        }
        if ($id == '1') {
            if (!isset($message["random_id"]) || empty($message["random_id"])) {
                $root_id = "";
            } else {
                $root_id = $message["random_id"];
            }
            if (!isset($message["time_of_pickup"]) || empty($message["time_of_pickup"])) {
                $pick_time = "";
            } else {
                $pick_time = $message["time_of_pickup"];
            }
            $payload = '{ "aps" :  { "alert" : "Hello",'
                    . ' "random_id" : "' . $root_id . '", '
                    . '"time_of_pickup":"' . $pick_time . '", '
                    . '"id":"' . $id . '", '
                    . '"badge" : 1, "sound" : "default" } }';
        }
        if ($id == '2') {
            if (!isset($message["random_id"]) || empty($message["random_id"])) {
                $root_id = "";
            } else {
                $root_id = $message["random_id"];
            }
            if (!isset($message["status"]) || empty($message["status"])) {
                $stat = "";
            } else {
                $stat = $message["status"];
            }
            if (!isset($message["message"]) || empty($message["message"])) {
                $msg = "";
            } else {
                $msg = $message["message"];
            }
            $payload = '{ "aps" :  { "alert" : "' . $msg . '",'
                    . ' "status" : "' . $stat . '", '
                    . ' "random_id" : "' . $root_id . '", '
                    . '"message":"' . $msg . '", '
                    . '"id":"' . $id . '", '
                    . '"badge" : 1, "sound" : "default" } }';
        }
        if ($id == '3') {
            if (!isset($message["random_id"]) || empty($message["random_id"])) {
                $root_id = "";
            } else {
                $root_id = $message["random_id"];
            }
            if (!isset($message["status"]) || empty($message["status"])) {
                $stat = "";
            } else {
                $stat = $message["status"];
            }
            if (!isset($message["message"]) || empty($message["message"])) {
                $msg = "";
            } else {
                $msg = $message["message"];
            }
            $payload = '{ "aps" :  { "alert" : "' . $msg . '",'
                    . ' "status" : "' . $stat . '", '
                    . ' "random_id" : "' . $root_id . '", '
                    . '"message":"' . $msg . '", '
                    . '"id":"' . $id . '", '
                    . '"badge" : 1, "sound" : "default" } }';
        }
        $result = 0;
        $bodyError = "";
        $msg = chr(0) . pack("n", 32) . pack('H*', str_replace(' ', '', $token)) . pack('n', (strlen($payload))) . $payload;
        $result = fwrite($this->fp, $msg);
        $bodyError .= 'result: ' . $result . ', devicetoken: ' . $token;
        if (!$result) {
            $errCounter = $errCounter + 1;
        }
        if ($result) {
            $bool_result = true;
        } else {
            $bool_result = false;
        }
        @socket_close($this->fp);
        @fclose($this->fp);
        return $bool_result;
    }

}
