<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
$response = "";

if (!isset($_POST[MOB_DRIVER_ID]) || empty($_POST[MOB_DRIVER_ID])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array("aps" => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $user_id = $_POST[MOB_DRIVER_ID];
    if (!isset($_POST[MOB_DRIVER_ID]) || empty($_POST[MOB_DRIVER_ID])) {

        $driver_info = mysql_query("SELECT * FROM " . DRIVER_DATA . " WHERE driver_id = '" . $user_id . "' AND is_on_root = '1'");
        $driver_info_count = mysql_num_rows($driver_info);
        if ($driver_info_count > 0) {
            $get_root_info = mysql_query("SELECT "
                    . "" . REQUEST_DATA . ".lattitude, "
                    . "" . REQUEST_DATA . ".logitude, "
                    . "" . REQUEST_DATA . ".random_id, "
                    . "" . REQUEST_DATA . ".driver_id, "
                    . "" . REQUEST_DATA . ".complete_status, "
                    . "" . CLIENT_DATA . ".name, "
                    . "CONCAT(" . CLIENT_DATA . ".country_code," . CLIENT_DATA . ".contact) AS contact "
                    . "FROM " . REQUEST_DATA . " "
                    . "LEFT JOIN " . CLIENT_DATA . " ON " . REQUEST_DATA . ".client_id=" . CLIENT_DATA . ".client_id "
                    . "WHERE " . REQUEST_DATA . ".driver_id='" . $user_id . "' ORDER BY " . REQUEST_DATA . ".request_id DESC LIMIT 1");
            $root_lat = "";
            $root_long = "";
            $root_id = "";
            $driver_id = "";
            $comp_stat = "";
            $client = "";
            $clint_nm = "";
            while ($row = mysql_fetch_array($get_root_info)) {
                $root_lat = $row['lattitude'];
                $root_long = $row['logitude'];
                $root_id = $row['random_id'];
                $driver_id = $row['driver_id'];
                $comp_stat = $row['complete_status'];
                $client = $row['contact'];
                $clint_nm = $row['name'];
            }
            $get_operator_data = mysql_query("SELECT * FROM operator_no LIMIT 1");
            $operator_number = "";
            while ($operator_row = @mysql_fetch_assoc($get_operator_data)) {
                $operator_number = $operator_row['operator'];
            }
            if ($comp_stat > 0) {
                $response = array("alert" => JOB_DONE, "id" => "2", "badge" => 1, "sound" => "default");
            } else {
//                $response = array("alert" => REQ_ASS_DRI, "random_id" => "$root_id", "lattitude" => "$root_lat", "logitude" => "$root_long", "client_contact" => "$client", "operator_contact" => "$operator_number", "client_name" => $clint_nm, "id" => "1", "badge" => 1, "sound" => "default");
                $response = array("alert" => REQ_ASS_DRI, "random_id" => "$root_id", "lattitude" => "$root_lat", "logitude" => "$root_long", "operator_contact" => "$operator_number", "client_name" => $clint_nm, "id" => "1", "badge" => 1, "sound" => "default");
            }
        } else {
            $response = array("alert" => REQ_ASS_DEL, "id" => "2", "badge" => 1, "sound" => "default");
        }
    } else {

        $random_id = $_POST[MOB_DRIVER_ID];
        $driver_info = mysql_query("SELECT * FROM " . DRIVER_DATA . " WHERE driver_id = '" . $user_id . "' AND random_id <> 'NULL' AND is_on_root = '0'");
        $driver_info_count = mysql_num_rows($driver_info);
        if ($driver_info_count > 0) {

            $get_root_info = mysql_fetch_assoc($driver_info);
            $client_random_id = $get_root_info['random_id'];
            $client_request = mysql_query("SELECT client_request_data.request_id, client_request_data.random_id, client_request_data.request_time, client_request_data.lattitude, client_request_data.logitude, client_request_data.client_id, client_request_data.time_of_pickup, client_request_data.driver_reached_time, client_request_data.request_status, client_request_data.complete_status, client_request_data.cancel_flg,client_request_data.end_lat,client_request_data.end_long,client_data.name,client_data.email,client_data.profile_image,client_data.contact,client_request_data.car_washing,client_request_data.fuel_topup,client_request_data.payment_status
                                FROM client_request_data
                                LEFT JOIN client_data
                                ON client_request_data.client_id = client_data.client_id
                                WHERE client_request_data.random_id = '{$client_random_id}'");
            $root_info_count = mysql_num_rows($client_request);
            if ($root_info_count > 0) {
                $root_lat = "";
                $root_long = "";
                $root_id = "";
                $driver_id = "";
                $comp_stat = "";
                $client = "";
                $clint_nm = "";
                $car_washing = "";
                $fuel_topup = "";
                $payment_status = "";
                $profile_image = "";
                $client_id = "";
                while ($row = mysql_fetch_assoc($client_request)) {

                    $root_lat = $row['lattitude'];
                    $root_long = $row['logitude'];
                    $root_id = $row['random_id'];
                    $driver_id = $row['driver_id'];
                    $comp_stat = $row['complete_status'];
                    $client = $row['contact'];
                    $client_id = $row['client_id'];
                    $clint_nm = $row['name'];
                    $car_washing = $row['car_washing'];
                    $fuel_topup = $row['fuel_topup'];
                    $payment_status = $row['payment_status'];
                    $profile_image = $row['profile_image'];
                }
                $get_operator_data = mysql_query("SELECT * FROM operator_no LIMIT 1");
                $operator_number = "";
                while ($operator_row = @mysql_fetch_assoc($get_operator_data)) {
                    $operator_number = $operator_row['operator'];
                }
                $driver_request = mysql_query("SELECT `drop_time` from client_request_data WHERE `driver_id`={$user_id}");
                $driver_response = mysql_fetch_assoc($driver_request);
                $driver_drop_time = $driver_response['drop_time'];
                if ($comp_stat > 0) {

                    $response = array("alert" => JOB_DONE, "id" => "2", "badge" => 1, "sound" => "default");
                    $response = array("alert" => REQ_ASS_DRI, "random_id" => "$root_id", "lattitude" => "$root_lat", "logitude" => "$root_long", "client_contact" => "$client", "operator_contact" => "$operator_number", "client_id" => $client_id, "client_name" => $clint_nm, "id" => "1", "badge" => 1, "sound" => "default", "car_washing" => $car_washing, "fuel_topup" => $fuel_topup, "payment_status" => $payment_status, MOB_CLIENT_PROFILE_IMAGE => $profile_image);
                } else if ($driver_drop_time > 0) {

                    $response = array("alert" => JOB_DONE, "id" => "1", "badge" => 1, "sound" => "default");
                    $response = array("alert" => REQ_ASS_DRI, "random_id" => "$root_id", "lattitude" => "$root_lat", "logitude" => "$root_long", "client_contact" => "$client", "operator_contact" => "$operator_number", "client_name" => $clint_nm,"client_id" => $client_id, "id" => "2", "badge" => 1, "sound" => "default", "car_washing" => $car_washing, "fuel_topup" => $fuel_topup, "payment_status" => $payment_status, MOB_CLIENT_PROFILE_IMAGE => $profile_image);
                    $driver_update_time = mysql_query("UPDATE client_request_data set `drop_time`='0' WHERE `driver_id`={$user_id}");
                } else if (!empty($root_id)) {
                    $response = array("alert" => REQ_ASS_DRI, "random_id" => "$root_id", "lattitude" => "$root_lat", "logitude" => "$root_long", "client_contact" => "$client", "operator_contact" => "$operator_number", "client_name" => $clint_nm,"client_id" => $client_id, "id" => "3", "badge" => 1, "sound" => "default", "car_washing" => $car_washing, "fuel_topup" => $fuel_topup, "payment_status" => $payment_status, MOB_CLIENT_PROFILE_IMAGE => $profile_image);
                }
            } else {
                $response = array("alert" => REQ_ASS_DEL, "id" => "4", "badge" => 1, "sound" => "default");
            }
        } else {
            $response = array("alert" => REQ_ASS_DEL, "id" => "4", "badge" => 1, "sound" => "default");
        }
    }
    echo json_encode(array("aps" => $response), JSON_PRETTY_PRINT);
}
?>