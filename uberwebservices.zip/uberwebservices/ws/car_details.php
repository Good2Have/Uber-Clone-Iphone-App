<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if ((!isset($_POST['client_id']) || empty($_POST['client_id'])) || (!isset($_POST['car_color']) || empty($_POST['car_color'])) || (!isset($_POST['car_model']) || empty($_POST['car_model'])) || (!isset($_POST['year_of_registration']) || empty($_POST['year_of_registration']) || (!isset($_POST['car_number_plate']) || empty($_POST['car_number_plate'])))) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {

    $db_select = mysql_select_db(DB_DATABASE, $con);
    $client_id = $_POST['client_id'];
    $car_model = $_POST['car_model'];
    $car_color = $_POST['car_color'];
    $year_of_registration = $_POST['year_of_registration'];
    $car_number_plate = $_POST['car_number_plate'];


    $car_insert = mysql_query("INSERT INTO car_details(`client_id`,`car_model`,`car_color`,`year_of_registration`,`car_number_plate`)VALUES({$client_id},'$car_model','{$car_color}','$year_of_registration','$car_number_plate')ON DUPLICATE KEY UPDATE car_color = '{$car_color}',car_model='{$car_model}',year_of_registration='{$year_of_registration}',car_number_plate='{$car_number_plate}'");

    $car_response = mysql_insert_id();

    if ($car_response > 0) {
        $car_select = mysql_query("SELECT * from car_details WHERE car_id = {$car_response}");
        $car_select_response = mysql_fetch_assoc($car_select);
        if ($car_select_response > 0) {
            $details = array('client_id' => "" . $car_select_response['client_id'], 'car_color' => "" . $car_select_response['car_color'], 'car_model' => "" . $car_select_response['car_model'], 'year_of_registration' => "" . $car_select_response['year_of_registration'], 'car_number_plate' => "" . $car_select_response['car_number_plate']);
            $response = array(STATUS => SUCCESS, MESSAGE => "Car Registered Successfully", DETAILS => $details);
        } else {
            echo $response = array(STATUS => FAIL, MESSAGE => "Car Id not found in the database");
        }
    } else {
        echo $response = array(STATUS => FAIL, MESSAGE => "Car not registered successfully");
    }

    echo json_encode($response);
}

    