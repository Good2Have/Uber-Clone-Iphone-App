<?php

include_once './const.php';
include_once './config.php';
include_once './paypal_functions.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
$response = "";

//CREATE CLASS OBJECT
$objPaypal = new paypalRequestManager();


if (    (!isset($_REQUEST['CLIENT_ID']) || empty($_REQUEST['CLIENT_ID']))  ||
        (!isset($_REQUEST['CORRELATION_ID']) || empty($_REQUEST['CORRELATION_ID']))  ||
        (!isset($_REQUEST['REFRESH_TOKEN']) || empty($_REQUEST['REFRESH_TOKEN']))  ||
        (!isset($_REQUEST['CARD_NUMBER']) || empty($_REQUEST['CARD_NUMBER']))  ||
        (!isset($_REQUEST['CARD_TYPE']) || empty($_REQUEST['CARD_TYPE'])) || 
        (!isset($_REQUEST['CARD_EXPIRE_MONTH']) || empty($_REQUEST['CARD_EXPIRE_MONTH'])) || 
        (!isset($_REQUEST['CARD_EXPIRE_YEAR']) || empty($_REQUEST['CARD_EXPIRE_YEAR'])) || 
        (!isset($_REQUEST['CARD_CVV2']) || empty($_REQUEST['CARD_CVV2'])) || 
        (!isset($_REQUEST['CARD_FIRST_NAME']) || empty($_REQUEST['CARD_FIRST_NAME'])) || 
        (!isset($_REQUEST['CARD_LAST_NAME']) || empty($_REQUEST['CARD_LAST_NAME'])) || 
        (!isset($_REQUEST['BILLING_ADDRESS']) || empty($_REQUEST['BILLING_ADDRESS'])) || 
        (!isset($_REQUEST['CITY']) || empty($_REQUEST['CITY'])) || 
        (!isset($_REQUEST['STATE']) || empty($_REQUEST['STATE'])) ||
        (!isset($_REQUEST['POSTAL_CODE']) || empty($_REQUEST['POSTAL_CODE']))||
        (!isset($_REQUEST['COUNTRY_CODE']) || empty($_REQUEST['COUNTRY_CODE'])) ||
        (!isset($_REQUEST['CURRENCY']) || empty($_REQUEST['CURRENCY'])) ||
        (!isset($_REQUEST['SUB_TOTAL']) || empty($_REQUEST['SUB_TOTAL'])) ||
        (!isset($_REQUEST['TAX']) || empty($_REQUEST['TAX'])) ||
        (!isset($_REQUEST['SHIPPING']) || empty($_REQUEST['SHIPPING']))||
        (!isset($_REQUEST['DESCRIPTION']) || empty($_REQUEST['DESCRIPTION']))
    )
{
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response)); exit();
    
    
    
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    
    $refresh_token = $_REQUEST['REFRESH_TOKEN'];    
    $paypal_access_token = $objPaypal->getAccessToken($refresh_token);
    $total_amount = $_REQUEST['SUB_TOTAL']+$_REQUEST['TAX']+$_REQUEST['SHIPPING'];
    //post credit card details details for payment
    $postdata = '{
  "intent":"sale",
  "payer":{
    "payment_method":"credit_card",
    "funding_instruments":[
      {
        "credit_card":{
          "number":"'.$_REQUEST['CARD_NUMBER'].'",
          "type":"'.$_REQUEST['CARD_TYPE'].'",
          "expire_month":'.$_REQUEST['CARD_EXPIRE_MONTH'].',
          "expire_year":'.$_REQUEST['CARD_EXPIRE_YEAR'].',
          "cvv2":"'.$_REQUEST['CARD_CVV2'].'",
          "first_name":"'.$_REQUEST['CARD_FIRST_NAME'].'",
          "last_name":"'.$_REQUEST['CARD_LAST_NAME'].'",
          "billing_address":{
            "line1":"'.$_REQUEST['BILLING_ADDRESS'].'",
            "city":"'.$_REQUEST['CITY'].'",
            "state":"'.$_REQUEST['STATE'].'",
            "postal_code":"'.$_REQUEST['POSTAL_CODE'].'",
            "country_code":"'.$_REQUEST['COUNTRY_CODE'].'"
          }
        }
      }
    ]
  },
  "transactions":[
    {
      "amount":{
        "total":"'.$total_amount.'",
        "currency":"'.$_REQUEST['CURRENCY'].'",
        "details":{
          "subtotal":"'.$_REQUEST['SUB_TOTAL'].'",
          "tax":"'.$_REQUEST['TAX'].'",
          "shipping":"'.$_REQUEST['SHIPPING'].'"
        }
      },
      "description":"'.$_REQUEST['DESCRIPTION'].'."
    }
  ]
}';
    

        //make payment with payment_method credit_card
        $response = $objPaypal->make_post_call($objPaypal->paymentUrl, $postdata,$paypal_access_token,$_REQUEST['CORRELATION_ID']);
        //FINAL OUTPUT
        echo stripcslashes(json_encode(array(JSON_ROOT_OBJECT => $response)));exit();
}



