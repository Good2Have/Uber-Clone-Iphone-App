<?php

include_once './const.php';
include_once './config.php';

function unique($use = "") {
    $mt = str_replace(".", "", str_replace(" ", "", microtime()));
    $unique = substr(number_format($mt * rand(), 0, '', ''), 0, 10);
    return $unique;
}

if (!file_exists($_FILES["image_upload"]["name"]) && $_FILES["image_upload"]["size"] == "") {
    
} else {
    $imageName = $_FILES["image_upload"]["name"];
    $imageTmpLoc = $_FILES["image_upload"]["tmp_name"];
    $imageNamePath = unique() . $imageName;
    $imagepathAndName = "../uploads/" . $imageNamePath;
    if (file_exists($imagepathAndName)) {
        
    } else {
        if (move_uploaded_file($_FILES["image_upload"]["tmp_name"], $imagepathAndName)) {
            
        }
    }
}

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
if ((!isset($_POST[MOB_DRIVER_NAME]) || empty($_POST[MOB_DRIVER_NAME])) || (!isset($_POST[MOB_DRIVER_EMAIL]) || empty($_POST[MOB_DRIVER_EMAIL])) || (!isset($_POST[MOB_DRIVER_PASS]) || empty($_POST[MOB_DRIVER_PASS])) || (!isset($_POST[MOB_DRIVER_CONTACT]) || empty($_POST[MOB_DRIVER_CONTACT])) || (!isset($_POST[MOB_DRIVER_DEVICE_TOKEN]) || empty($_POST[MOB_DRIVER_DEVICE_TOKEN]))) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    if (!isset($_POST[MOB_DRIVER_GENDER]) || empty($_POST[MOB_DRIVER_GENDER])) {
        $gender = "Male";
    } else {
        $gender = ucwords($_POST[MOB_DRIVER_GENDER]);
    }
    $name = ucwords(trim($_POST[MOB_DRIVER_NAME]));
    $email = $_POST[MOB_DRIVER_EMAIL];
    $password = $_POST[MOB_DRIVER_PASS];
    $contact = $_POST[MOB_DRIVER_CONTACT];
    $phone_code = "";
    if (!isset($_POST[MOB_DRIVER_PHONE_CODE]) || empty($_POST[MOB_DRIVER_PHONE_CODE])) {
        $phone_code = "0";
    } else {
        $phone_code = $_POST[MOB_DRIVER_PHONE_CODE];
    }
    if (!isset($_POST[MOB_DRIVER_LAT]) || empty($_POST[MOB_DRIVER_LAT])) {
        $let = '0';
    } else {
        $let = $_POST[MOB_DRIVER_LAT];
    }
    if (!isset($_POST[MOB_DRIVER_LONG]) || empty($_POST[MOB_DRIVER_LONG])) {
        $long = '0';
    } else {
        $long = $_POST[MOB_DRIVER_LONG];
    }
    $token = $_POST[MOB_DRIVER_DEVICE_TOKEN];
    $device_type = $_POST[MOB_DRIVER_DEVICE_TYPE];
    if ($device_type == '0' || $device_type == 'android') {
        $device_type = '0';
    } else {
        $device_type = '1';
    }
    $dateNow = date('Y-m-d H:i:s', time());

    $check_avaiailable = mysql_query("SELECT * FROM " . DRIVER_DATA . " WHERE email = '" . $email . "'");
    $check_count = mysql_num_rows($check_avaiailable);
    if ($check_count > 0) {
        $response = array(STATUS => FAIL, MESSAGE => EMAL_ALREADY_REGISTERED);
    } else {
        $reg_user = mysql_query("INSERT INTO " . DRIVER_DATA . "(name, email, password, contact, lattitude, logitude, device_token, device_type, reg_time,country_code,profile_image) VALUES ('$name','$email','$password','$contact','$let','$long','$token','$device_type','$dateNow','$phone_code','$imageNamePath')");
        if ($reg_user) {
            $insert_id = mysql_insert_id();
            $details = array();
            if ($insert_id > 0) {
                $details = array(MOB_DRIVER_ID => "" . $insert_id, MOB_DRIVER_NAME => $name, MOB_DRIVER_EMAIL => $email, MOB_DRIVER_CONTACT => $contact, MOB_DRIVER_LAT => $let, MOB_DRIVER_LONG => $long, MOB_DRIVER_RATE => "0", MOB_DRIVER_RATE_COUNT => "0", MOB_DRIVER_CONF_STAT => "0", MOB_DRIVER_REG_TIME => $dateNow, MOB_DRIVER_PHONE_CODE => "" . $phone_code, MOB_CLIENT_PROFILE_IMAGE => "" . $imageNamePath);
                $response = array(STATUS => SUCCESS, MESSAGE => USER_REG_SUCCESS, DETAILS => $details);
            } else {
                $response = array(STATUS => FAIL, MESSAGE => USER_REG_FAIL);
            }
        } else {
            $response = array(STATUS => FAIL, MESSAGE => USER_REG_FAIL);
        }
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>