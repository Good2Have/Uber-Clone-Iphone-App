<?php

include_once './const.php';
include_once './config.php';
include_once './GCM.php';
include_once './apns_driver.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if ((!isset($_POST[MOB_REQUEST_RANDOM_ID]) || empty($_POST[MOB_REQUEST_RANDOM_ID])) || (!isset($_POST[MOB_FEEDBACK_TIME]) || empty($_POST[MOB_FEEDBACK_TIME]))) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $trip_id = trim($_POST[MOB_REQUEST_RANDOM_ID]);
    $reached_time = trim($_POST[MOB_FEEDBACK_TIME]);
    $update_trip = mysql_query("UPDATE " . REQUEST_DATA . " SET driver_reached_time='$reached_time' WHERE random_id='$trip_id'");
    $is_update = mysql_affected_rows();
    if ($is_update > 0) {
        $get_trip_data = mysql_query("SELECT "
                . "" . REQUEST_DATA . ".random_id, "
                . "" . REQUEST_DATA . ".client_id, "
                . "" . REQUEST_DATA . ".driver_id, "
                . "" . DRIVER_DATA . ".device_type AS 'driver_device', "
                . "" . DRIVER_DATA . ".device_token AS 'driver_token', "
                . "" . CLIENT_DATA . ".device_type AS 'client_device_type', "
                . "" . CLIENT_DATA . ".device_token AS 'client_device' "
                . "FROM " . REQUEST_DATA . " "
                . "LEFT JOIN " . CLIENT_DATA . " ON " . REQUEST_DATA . ".client_id = " . CLIENT_DATA . ".client_id "
                . "LEFT JOIN " . DRIVER_DATA . " ON " . REQUEST_DATA . ".driver_id = " . DRIVER_DATA . ".driver_id "
                . "WHERE " . REQUEST_DATA . ".random_id = '$trip_id'");
        $check_trip = mysql_num_rows($get_trip_data);
        if ($check_trip > 0) {
            $raandom_id = "";
            $client_id = "";
            $driver_id = "";
            $driver_device_type = "";
            $driver_device_token = "";
            $client_device_type = "";
            $client_device_token = "";
            while ($row = mysql_fetch_assoc($get_trip_data)) {
                $raandom_id = $row['random_id'];
                $client_id = $row['client_id'];
                $driver_id = $row['driver_id'];
                $driver_device_type = $row['driver_device'];
                $driver_device_token = $row['driver_token'];
                $client_device_type = $row['client_device_type'];
                $client_device_token = $row['client_device'];
            }
            $client_device_token = str_replace(' ', '', $client_device_token);
            if ($client_device_type == '0') {
                $gcm = new GCM();
                $registatoin_ids = array($client_device_token);

                $message = array(STATUS => SUCCESS, MOB_REQUEST_RANDOM_ID => $raandom_id, MESSAGE => DRIVER_REACHED_TO_CLIENT, 'id' => '5');
                $and_push = array("message" => $message);

                $gcm->send_notification($registatoin_ids, $and_push);
                $response = array(STATUS => SUCCESS, MESSAGE => REACHED_TIME_UPDATE, MOB_REQUEST_RANDOM_ID => $raandom_id);
            } else {
                $Objapns = new Apns_Driver();
                $message = array(
                    'id' => '2',
                    'random_id' => $raandom_id,
                    'status' => 'succesfull',
                    'message' => 'DRIVER_REACHED_TO_CLIENT'
                );
                $Objapns->send_notification($client_device_token, $message);

                $response = array(STATUS => SUCCESS, MESSAGE => REACHED_TIME_UPDATE, MOB_REQUEST_RANDOM_ID => $raandom_id);
            }
        } else {
            $response = array(STATUS => FAIL, MESSAGE => TRIP_NOT_FOUND);
        }
    } else {
        $response = array(STATUS => FAIL, MESSAGE => REACHED_TIME_NOT_UPDATE);
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>