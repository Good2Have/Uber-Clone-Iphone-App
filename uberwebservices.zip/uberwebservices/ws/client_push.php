<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
$response = "";
if ((!isset($_POST[USER_ID]) || empty($_POST[USER_ID]))) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array("aps" => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $user_id = $_POST[USER_ID];
    if (!isset($_POST[MOB_REQUEST_RANDOM_ID]) || empty($_POST[MOB_REQUEST_RANDOM_ID])) {
        $get_root_info = mysql_query("SELECT * FROM " . REQUEST_DATA . " WHERE client_id='" . $user_id . "' AND complete_status = '0' ORDER BY request_id DESC LIMIT 1");
        $root_info_count = mysql_num_rows($get_root_info);
        if ($root_info_count > 0) {
            while ($row = mysql_fetch_array($get_root_info)) {
                $req_id = $row['request_id'];
                $root_id = $row['random_id'];
                $req_time = $row['request_time'];
                $root_lat = $row['lattitude'];
                $root_long = $row['logitude'];
                $req_client = $row['client_id'];
                $driver_id = $row['driver_id'];
                $pickup_time = $row['time_of_pickup'];
                $driver_reached_time = $row['driver_reached_time'];
                $req_status = $row['request_status'];
                $comp_stat = $row['complete_status'];
                $req_cncl = $row['cancel_flg'];
            }
            if ($comp_stat > 0) {
                $response = array("alert" => TRIP_FINISH_TO_CLIENT, STATUS => SUCCESS, "random_id" => "$root_id", MESSAGE => TRIP_FINISH_TO_CLIENT, "id" => "2", "badge" => 1, "sound" => "default");
            } else if ($driver_reached_time != 0) {
                $response = array("alert" => DRIVER_REACHED_TO_CLIENT, STATUS => SUCCESS, "random_id" => "$root_id", MESSAGE => DRIVER_REACHED_TO_CLIENT, "id" => "5", "badge" => 1, "sound" => "default");
            } else if ($pickup_time != 0) {
                $response = array("alert" => PICKUP_TIME_MSG, "random_id" => "$root_id", "time_of_pickup" => "$pickup_time", "id" => "1", "badge" => 1, "sound" => "default");
            } else {
                $response = array("alert" => JOURNY_REQ_SUCCESS, MOB_REQUEST_ID => "" . $req_id, MOB_REQUEST_RANDOM_ID => $root_id, MOB_REQUEST_TIME => $req_time, MOB_REQUEST_LAT => $root_lat, MOB_REQUEST_LONG => $root_long, MOB_REQUEST_CLIENT_ID => $req_client, MOB_REQUEST_DRIVER_ID => $driver_id, MOB_REQUEST_PICK_TIME => $pickup_time, MOB_REQUEST_STATUS => $req_status, MOB_REQUEST_OVER_STAT => $comp_stat, MOB_REQUEST_CANCLE => $req_cncl, "id" => "0", "badge" => 1, "sound" => "default");
            }
        } else {
            $response = array("alert" => REQ_ASS_DEL, "id" => "4", "badge" => 1, "sound" => "default");
        }
    } else {
        $random_id = $_POST[MOB_REQUEST_RANDOM_ID];
        $get_root_info = mysql_query("SELECT * FROM " . REQUEST_DATA . " WHERE random_id = '" . $random_id . "' AND client_id='" . $user_id . "' ORDER BY request_id DESC LIMIT 1");
        $root_info_count = mysql_num_rows($get_root_info);
        if ($root_info_count > 0) {
            $pickup_time = "";
            while ($row = mysql_fetch_array($get_root_info)) {
                $req_id = $row['request_id'];
                $root_id = $row['random_id'];
                $req_time = $row['request_time'];
                $root_lat = $row['lattitude'];
                $root_long = $row['logitude'];
                $req_client = $row['client_id'];
                $driver_id = $row['driver_id'];
                $pickup_time = $row['time_of_pickup'];
                $driver_reached_time = $row['driver_reached_time'];
                $req_status = $row['request_status'];
                $comp_stat = $row['complete_status'];
                $req_cncl = $row['cancel_flg'];
            }
            if ($comp_stat > 0) {
                $response = array("alert" => TRIP_FINISH_TO_CLIENT, STATUS => SUCCESS, "random_id" => "$root_id", MESSAGE => TRIP_FINISH_TO_CLIENT, "id" => "2", "badge" => 1, "sound" => "default");
            } else if ($pickup_time != 0) {
                $response = array("alert" => PICKUP_TIME_MSG, "random_id" => "$root_id", "time_of_pickup" => "$pickup_time", "id" => "1", "badge" => 1, "sound" => "default");
                $pick_up_time = mysql_query("UPDATE client_request_data set `time_of_pickup`='0' WHERE `client_id`={$req_client}");
            } else if ($driver_reached_time != 0) {
                $response = array("alert" => DRIVER_REACHED_TO_CLIENT, STATUS => SUCCESS, "random_id" => "$root_id", "time_of_pickup" => "$pickup_time", MESSAGE => DRIVER_REACHED_TO_CLIENT, "id" => "5", "badge" => 1, "sound" => "default");
            } else {
                $response = array("alert" => JOURNY_REQ_SUCCESS, MOB_REQUEST_ID => "" . $req_id, MOB_REQUEST_RANDOM_ID => $root_id, MOB_REQUEST_TIME => $req_time, MOB_REQUEST_LAT => $root_lat, MOB_REQUEST_LONG => $root_long, MOB_REQUEST_CLIENT_ID => $req_client, MOB_REQUEST_DRIVER_ID => $driver_id, MOB_REQUEST_PICK_TIME => $pickup_time, MOB_REQUEST_STATUS => $req_status, MOB_REQUEST_OVER_STAT => $comp_stat, MOB_REQUEST_CANCLE => $req_cncl, "id" => "0", "badge" => 1, "sound" => "default");
            }
        } else {
            $response = array("alert" => REQ_ASS_DEL, "id" => "4", "badge" => 1, "sound" => "default");
        }
    }
    echo json_encode(array("aps" => $response));
}
?>