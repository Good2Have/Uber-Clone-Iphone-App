<html>
    <title>About-Us</title>
    <style>
        @font-face {
            font-family: 'roboto-light';
            src:url('roboto-light.eot');
            src:url('roboto-light.eot?#iefix') format('embedded-opentype'),
                url('roboto-light.svg#iconfont') format('svg'),
                url('roboto-light.woff') format('woff'),
                url('roboto-light.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
        }
        body{font-family: roboto-light;background-color: #4f4f4f; color: #271B1B; text-align: center;background: #ffffff;
             /* Old browsers */
             /* IE9 SVG, needs conditional override of 'filter' to 'none' */
             background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPHJhZGlhbEdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgY3g9IjUwJSIgY3k9IjUwJSIgcj0iNzUlIj4KICAgIDxzdG9wIG9mZnNldD0iMCUiIHN0b3AtY29sb3I9IiNmZmZmZmYiIHN0b3Atb3BhY2l0eT0iMSIvPgogICAgPHN0b3Agb2Zmc2V0PSIxMDAlIiBzdG9wLWNvbG9yPSIjZTBlMGUwIiBzdG9wLW9wYWNpdHk9IjEiLz4KICA8L3JhZGlhbEdyYWRpZW50PgogIDxyZWN0IHg9Ii01MCIgeT0iLTUwIiB3aWR0aD0iMTAxIiBoZWlnaHQ9IjEwMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
             background: -moz-radial-gradient(center, ellipse cover,  #ffffff 0%, #e0e0e0 100%); /* FF3.6+ */
             background: -webkit-gradient(radial, center center, 0px, center center, 100%, color-stop(0%,#ffffff), color-stop(100%,#e0e0e0)); /* Chrome,Safari4+ */
             background: -webkit-radial-gradient(center, ellipse cover,  #ffffff 0%,#e0e0e0 100%); /* Chrome10+,Safari5.1+ */
             background: -o-radial-gradient(center, ellipse cover,  #ffffff 0%,#e0e0e0 100%); /* Opera 12+ */
             background: -ms-radial-gradient(center, ellipse cover,  #ffffff 0%,#e0e0e0 100%); /* IE10+ */
             background: radial-gradient(ellipse at center,  #ffffff 0%,#e0e0e0 100%); /* W3C */
             filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#e0e0e0',GradientType=1 ); /* IE6-8 fallback on horizontal gradient */}
        body h1{font-size: 2.0em;}
        body p{margin: 25px 10px 35px 10px; font-size: 1.3em;}
        body button{cursor: pointer;background-color: #514949; border: 0;padding: 10px; margin-right: 10px;width: 45%; color: #fbfdfa;font-family: roboto-light;font-size: 1.2em;font-weight: bold;-webkit-border-radius: 0px;-moz-border-radius: 0px;border-radius: 0px;transition: background-color 500ms ease 0s;-moz-transition: background-color 500ms ease 0s;-webkit-transition: background-color 500ms ease 0s;-o-transition: background-color 500ms ease 0s;behavior: url(PIE.htc);}
        body button:last-child{margin-right: 0px;}
        body button:hover{background-color: #271B1B;}
        body .foot_icon {width: 30%;position: fixed;bottom: 0;right: 0;z-index: -1;}
        body .foot_icon img{width:100%;}
        @media only screen and (max-width: 1000px){
            body p{margin: 25px 10px 35px 10px; font-size: 1.2em;}
            body h1{font-size: 1.8em;}
        }
        @media only screen and (max-width: 800px){
            body p{margin: 25px 10px 35px 10px; font-size: 1.1em;}
            body button{font-size: 1.1em;}
            body h1{font-size: 1.7em;}
        }
        @media only screen and (max-width: 600px){
            body p{margin: 25px 10px 35px 10px; font-size: 1em;}
            body button{font-size: 1em;}
            body h1{font-size: 1.6em;}
        }
        @media only screen and (max-width: 400px){
            body p{margin: 25px 10px 35px 10px; font-size: 0.8em;}
            body button{font-size: 0.8em;}
            body h1{font-size: 1.5em;}
        }
    </style>
    <body>
        <?php
        include_once './const.php';
        include_once './config.php';

        $con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
        $db_select = mysql_select_db(DB_DATABASE, $con);
        $details = array();
        $check_id = mysql_query("SELECT * FROM about_us LIMIT 1");
        $count1 = mysql_num_rows($check_id);
        if ($count1 > 0) {
            while ($row = mysql_fetch_array($check_id)) {
                $id = $row['id'];
                $about = $row['about'];
                $link_1 = $row['link_1'];
                $link_2 = $row['link_2'];
            }

            echo"<!--<h1>About Us</h1>-->"
            . "<p>$about</p>"
            . "<button onclick=\"location.href='" . $link_1 . "'\">Privacy Policy</button>"
            . "<button onclick=\"location.href='" . $link_2 . "'\">Contact Us</button>";
        } else {
            echo "<h1 style='text-align:center;'>DATA NOT AVAILABLE...</h1>";
        }
        ?>
        <div class="foot_icon"><img src="icon.png"></div>
    </body>
</html>
