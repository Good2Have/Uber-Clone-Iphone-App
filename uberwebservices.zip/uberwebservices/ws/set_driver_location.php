<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if (!isset($_POST[MOB_DRIVER_ID]) || empty($_POST[MOB_DRIVER_ID])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $driver_id = $_POST[MOB_DRIVER_ID];
    if (!isset($_POST[MOB_DRIVER_LAT]) || empty($_POST[MOB_DRIVER_LAT])) {
        $driver_lat = "0";
    } else {
        $driver_lat = $_POST[MOB_DRIVER_LAT];
    }
    if (!isset($_POST[MOB_DRIVER_LONG]) || empty($_POST[MOB_DRIVER_LONG])) {
        $driver_long = "0";
    } else {
        $driver_long = $_POST[MOB_DRIVER_LONG];
    }
    if ($driver_lat == '0' || $driver_long == '0') {
        $response = array(STATUS => SUCCESS, MESSAGE => DRIVER_POS_UPDATED);
    } else {
        $update_driver_pos = mysql_query("UPDATE " . DRIVER_DATA . " SET lattitude='$driver_lat',logitude='$driver_long' WHERE driver_id='$driver_id'");
        if ($update_driver_pos > 0) {
            $response = array(STATUS => SUCCESS, MESSAGE => DRIVER_POS_UPDATED);
        } else {
            $response = array(STATUS => FAIL, MESSAGE => DRIVER_POS_UPDATED_FAIL);
        }
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>