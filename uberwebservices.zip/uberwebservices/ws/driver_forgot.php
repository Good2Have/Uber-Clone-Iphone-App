<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet" media="screen"> 
        <style type="text/css">
            .space{margin-top: 20%;}
        </style>
    <head>
    <body>
        <div class="container">
            <div class="space"></div>
            <div class="col-md-6 col-sm-offset-3">
                <div class="panel panel-danger">
                    <div class="panel-heading">
                        <h3 class="panel-title">Forgot Password</h3>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" action="" method="POST">
                            <div class="form-group">
                                <label for="email" class="col-sm-1 control-label">Email</label> 
                                <div class="col-sm-10">
                                    <input type="email" class="form-control" name ="email" id="email" placeholder="Email">

                                </div>

                            </div>

                            <div class="col-sm-offset-2 col-sm-5">
                                <button type="submit" name="submit" value="Send" class="btn btn-default">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php

function rand_str($len) {
// The alphabet the random string consists of
    $abc = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

// The default length the random key should have
    $defaultLength = 3;

// Ensure $len is a valid number
// Should be less than or equal to strlen( $abc ) but at least $defaultLength
    $len = max(min(intval($len), strlen($abc)), $defaultLength);

// Return snippet of random string as random string
    return substr(str_shuffle($abc), 0, $len);
}

// Example usage with a length of 25 chars
//echo 'Your random string is: ' . rand_str(8); // Example output: Your random string is: URwXWGTMDAebriKmEV4zdqJ2I
//die;

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
$response = "";
$db_select = mysql_select_db(DB_DATABASE, $con);

$email = $_POST['email'];
$passwordRand = rand_str(8);
$password = $passwordRand;
if ($email) {
    $clientExists = mysql_query("SELECT `email` FROM driver_data WHERE `email` = '$email'");
    $clientData = mysql_fetch_assoc($clientExists);
    if ($clientData) {
        $db_select = mysql_select_db(DB_DATABASE, $con);
        $query = mysql_query("update driver_data set password='" . $password . "' WHERE email ='" . $email . "'");
        $sql_query = mysql_affected_rows();

        if ($sql_query > 0) {
            $to = $email;
            $subject = 'Reset Your Password';
            $message = "Your new password is : {$passwordRand}  ";
            $headers = 'From:ABC@XYZ.com';
            $mail = mail($to, $subject, $message, $headers);
            ?>
            <div class="col-sm-6 col-sm-offset-3 text-center" >
                <?php echo '<p style="color:#5B9900;">Please check your Email ID. Password has been sent on your Email Address.</p>';
                ?></div><?php
        }
    } else {
        ?> <div class="col-sm-6 col-sm-offset-3 text-center" >
            <?php echo '<p style="color:#FF0000;">No client exist with this email id.</p>';
            ?></div><?php
        }
//        echo $response;
    }
    ?>




