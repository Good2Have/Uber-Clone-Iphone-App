<?php

include_once './const.php';
include_once './config.php';
include_once './paypal_functions.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
$response = "";

//CREATE CLASS OBJECT
$objPaypal = new paypalRequestManager();

if ((!isset($_POST['CLIENT_ID']) || empty($_POST['CLIENT_ID'])) ||
        (!isset($_POST['CORRELATION_ID']) || empty($_POST['CORRELATION_ID'])) ||
        (!isset($_POST['REFRESH_TOKEN']) || empty($_POST['REFRESH_TOKEN'])) ||
        (!isset($_POST['TOTAL']) || empty($_POST['TOTAL']))
) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
    exit();
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $refresh_token = $_POST['REFRESH_TOKEN'];
    $paypal_access_token = $objPaypal->getAccessToken($refresh_token);
    $total_amount = $_POST['TOTAL'];
    //post credit card details details for payment
    $postPaypalData = '{
  "intent":"authorize",
  "redirect_urls":{
    "return_url":"http://uber.globusapps.com/ws/",
    "cancel_url":"http://uber.globusapps.com/ws/"
  },
  "payer":{
    "payment_method":"paypal"
  },
  "transactions":[
    {
      "amount":{
        "total":"' . $total_amount . '",
        "currency":"USD"
      },
      "description":"' . $_POST['DESCRIPTION'] . '."
    }
  ]
}';


    //make payment with payment_method credit_card
    $response = $objPaypal->make_post_call($objPaypal->paymentUrl, $postPaypalData, $paypal_access_token, $_POST['CORRELATION_ID']);
    //FINAL OUTPUT
    echo stripcslashes(json_encode(array(JSON_ROOT_OBJECT => $response)));
    exit();
}
