<?php

include_once './const.php';
include_once './config.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if (!isset($_POST[USER_ID]) || empty($_POST[USER_ID])) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    if (!isset($_POST[IS_DRIVER]) || empty($_POST[IS_DRIVER])) {
        $is_driver = "0";
    } else {
        $is_driver = $_POST[IS_DRIVER];
    }
    $user_id = $_POST[USER_ID];

    if ($is_driver == 1) {
        $check_avaiailable = mysql_query("SELECT * FROM " . DRIVER_DATA . " WHERE driver_id = '" . $user_id . "'");
        $check_count = mysql_num_rows($check_avaiailable);
        if ($check_count > 0) {
            $details = array();
            while ($row = mysql_fetch_array($check_avaiailable)) {
                $user_id = $row['driver_id'];
                $name = $row['name'];
                $email = $row['email'];
                $contact = $row['contact'];
                $phone_code = $row['country_code'];
                $dob = $row['date_of_birth'];
                $gen = $row['gender'];
                $ref_no = $row['reference_no'];
                $let = $row['lattitude'];
                $long = $row['logitude'];
                $rating = $row['rating'];
                $rate_count = $row['rating_count'];
                $conf_stat = $row['confirm_status'];
                $reg_time = $row['reg_time'];
                $is_busy = $row['is_busy'];
            }
            if ($conf_stat == '1') {
                if ($is_busy == "0") {
                    $driver_busy = "" . AVAILABLE;
                } else {
                    $driver_busy = "" . NOT_AVAILABLE;
                }
                $details = array(MOB_DRIVER_ID => "" . $user_id, MOB_DRIVER_NAME => $name, MOB_DRIVER_EMAIL => $email, MOB_DRIVER_CONTACT => $contact, MOB_DRIVER_DOB => $dob, MOB_DRIVER_GENDER => $gen, MOB_DRIVER_REF_NO => $ref_no, MOB_DRIVER_LAT => $let, MOB_DRIVER_LONG => $long, MOB_DRIVER_RATE => "" . $rating, MOB_DRIVER_RATE_COUNT => "" . $rate_count, MOB_DRIVER_CONF_STAT => "" . $conf_stat, MOB_DRIVER_REG_TIME => $reg_time, MOB_DRIVER_IS_BUSY => $is_busy, MOB_DRIVER_BUSY_STA => $driver_busy, MOB_CLIENT_PHONE_CODE => "" . $phone_code);
                $response = array(STATUS => SUCCESS, MESSAGE => USER_PROFILE_SEND, DETAILS => $details);
            } else {
                $response = array(STATUS => FAIL, MESSAGE => USER_NOT_CONFIRM);
            }
        } else {
            $response = array(STATUS => FAIL, MESSAGE => USER_NOT_FOUND);
        }
    } else {
        $check_avaiailable = mysql_query("SELECT * FROM " . CLIENT_DATA . " WHERE client_id = '" . $user_id . "'");
        $check_count = mysql_num_rows($check_avaiailable);
        if ($check_count > 0) {
            $details = array();
            while ($row = mysql_fetch_array($check_avaiailable)) {
                $user_id = $row['client_id'];
                $name = $row['name'];
                $email = $row['email'];
                $contact = $row['contact'];
                $phone_code = $row['country_code'];
                $dob = $row['date_of_birth'];
                $gen = $row['gender'];
                $reg_time = $row['reg_time'];
            }
            $details = array(MOB_CLIENT_ID => "" . $user_id, MOB_CLIENT_NAME => $name, MOB_CLIENT_EMAIL => $email, MOB_CLIENT_CONTACT => $contact, MOB_CLIENT_DOB => $dob, MOB_DRIVER_GENDER => $gen, MOB_CLIENT_REG_TIME => $reg_time, MOB_CLIENT_PHONE_CODE => "" . $phone_code);
            $response = array(STATUS => SUCCESS, MESSAGE => USER_PROFILE_SEND, DETAILS => $details);
        } else {
            $response = array(STATUS => FAIL, MESSAGE => USER_NOT_FOUND);
        }
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>