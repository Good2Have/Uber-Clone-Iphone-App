<?php

include_once './const.php';
include_once './config.php';
include_once './apns_driver.php';

$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
if ((!isset($_POST[MOB_REQUEST_PICK_TIME]) || empty($_POST[MOB_REQUEST_PICK_TIME])) || (!isset($_POST[MOB_REQUEST_RANDOM_ID]) || empty($_POST[MOB_REQUEST_RANDOM_ID]))) {
    $response = array(STATUS => FAIL, MESSAGE => NO_BLANK_FIELD_ALLOW);
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
} else {
    $db_select = mysql_select_db(DB_DATABASE, $con);
    $pick_time = $_POST[MOB_REQUEST_PICK_TIME];
    $trip_id = $_POST[MOB_REQUEST_RANDOM_ID];
    $update_trip = mysql_query("UPDATE " . REQUEST_DATA . " SET time_of_pickup='$pick_time' WHERE random_id='$trip_id'");
    $is_up = mysql_affected_rows();
    if ($is_up > 0) {
        $get_trip_info = mysql_query("SELECT * FROM " . REQUEST_DATA . " WHERE random_id='$trip_id'");
        $check_count = mysql_num_rows($get_trip_info);
        if ($check_count) {
            $details = array();
            $client_id = "";
            $trip_id = "";
            $client_pick_time = "";
            while ($row = mysql_fetch_array($get_trip_info)) {
                $client_id = $row['client_id'];
                $trip_id = $row['random_id'];
                $client_pick_time = $row['time_of_pickup'];
            }
            $get_client_info = mysql_query("SELECT * FROM " . CLIENT_DATA . " WHERE client_id='$client_id'");
            $count_clint = mysql_num_rows($get_client_info);
            if ($count_clint > 0) {
                $device_token = "";
                while ($row1 = mysql_fetch_array($get_client_info)) {
                    $device_token = $row1['device_token'];
                    $device_type = $row1['device_type'];
                }
                $device_token = str_replace(' ', '', $device_token);
                $apns = new Apns_Driver();
                $message = array(
                    'id' => '1',
                    'random_id' => $trip_id,
                    'time_of_pickup' => $pick_time,
                    'status' => 'succesfull',
                    'message' => 'hello'
                );
                $apns->send_notification($device_token, $message);
                $response = array(STATUS => SUCCESS, MESSAGE => TRIP_TIME_SUCCESS_SET);
            } else {
                $response = array(STATUS => FAIL, MESSAGE => TRIP_CLIENT_NOT_FOUND);
            }
        } else {
            $response = array(STATUS => FAIL, MESSAGE => TRIP_NOT_FOUND);
        }
    } else {
        $response = array(STATUS => FAIL, MESSAGE => TRIP_TIME_NOT_SET);
    }
    echo json_encode(array(JSON_ROOT_OBJECT => $response));
}
?>